import { Action } from '../actions/action';
import { revealWotcSlot } from '../prefabs/wotc-facedown';
import { checkState } from '../effect-reducers/check-effect';
import { PassTurnAction, RetreatAction, RetreatStartAction, AttackAction, UseAbilityAction, UseStadiumAction, UseTrainerAbilityAction, UseEnergyAbilityAction } from '../actions/game-actions';
import { State, GamePhase } from '../state/state';
import { StoreLike } from '../store-like';
import { GameError } from '../../game-error';
import { GameMessage } from '../../game-message';
import { RetreatEffect, RetreatStartEffect, UseAttackEffect, UseEnergyPowerEffect, UsePowerEffect, UseStadiumEffect, UseTrainerPowerEffect } from '../effects/game-effects';
import { EndTurnEffect } from '../effects/game-phase-effects';
import { StateUtils } from '../state-utils';
import { SlotType } from '../actions/play-card-action';
import { PokemonCard } from '../card/pokemon-card';
import { CheckPokemonAttacksEffect, CheckPokemonPowersEffect } from '../effects/check-effects';
import { Attack } from '../card/pokemon-types';
import { TrainerCard } from '../card/trainer-card';
import { EnergyCard } from '../card/energy-card';

export function playerTurnReducer(store: StoreLike, state: State, action: Action): State {

  if (state.phase === GamePhase.PLAYER_TURN) {

    if (action instanceof PassTurnAction) {
      const player = state.players[state.activePlayer];

      if (player === undefined || player.id !== action.clientId) {
        throw new GameError(GameMessage.NOT_YOUR_TURN);
      }

      const endTurnEffect = new EndTurnEffect(player);

      state = store.reduceEffect(state, endTurnEffect);
      return state;
    }

    if (action instanceof RetreatAction) {
      const player = state.players[state.activePlayer];

      if (player === undefined || player.id !== action.clientId) {
        throw new GameError(GameMessage.NOT_YOUR_TURN);
      }

      const retreatEffect = new RetreatEffect(player, action.benchIndex);
      state = store.reduceEffect(state, retreatEffect);
      return state;
    }

    if (action instanceof RetreatStartAction) {
      const player = state.players[state.activePlayer];

      if (player === undefined || player.id !== action.clientId) {
        throw new GameError(GameMessage.NOT_YOUR_TURN);
      }

      state = store.reduceEffect(state, new RetreatStartEffect(player));
      return state;
    }

    if (action instanceof AttackAction) {
      const player = state.players[state.activePlayer];

      if (player === undefined || player.id !== action.clientId) {
        throw new GameError(GameMessage.NOT_YOUR_TURN);
      }

      if(player.active.getPokemonCard()?._wotcConcealedCard&&revealWotcSlot(store,state,player.active))return checkState(store,state);
      const pokemonCard = player.active.getPokemonCard();
      let attacks: Attack[] = [];

      if (pokemonCard) {
        attacks = [...pokemonCard.attacks];
      }

      // Add bench attacks
      player.bench.forEach(benchSlot => {
        const benchPokemon = benchSlot.getPokemonCard();
        if (benchPokemon && benchPokemon.attacks.some(attack => attack.useOnBench)) {
          const benchAttacks = benchPokemon.attacks.filter(attack => attack.useOnBench);
          attacks.push(...benchAttacks);
          const attackEffect = new CheckPokemonAttacksEffect(player);
          state = store.reduceEffect(state, attackEffect);
          attacks = [...attacks, ...attackEffect.attacks];
        }
      });

      const attackEffect = new CheckPokemonAttacksEffect(player);
      state = store.reduceEffect(state, attackEffect);

      attacks = [...attacks, ...attackEffect.attacks];

      const attack = attacks.find(a => a.name === action.name);

      if (attack === undefined) {
        throw new GameError(GameMessage.UNKNOWN_ATTACK);
      }

      const useAttackEffect = new UseAttackEffect(player, attack);
      useAttackEffect.delegateFrom=attackEffect.attackSources.get(attack);
      state = store.reduceEffect(state, useAttackEffect);

      state.lastAttack = attack;

      if (!state.playerLastAttack) {
        state.playerLastAttack = {};
      }
      if (pokemonCard) {
        state.playerLastAttack[player.id] = { attack, sourceCard: pokemonCard };
      }

      return state;
    }

    if (action instanceof UseAbilityAction) {
      const player = state.players[state.activePlayer];

      if (player === undefined || player.id !== action.clientId) {
        throw new GameError(GameMessage.NOT_YOUR_TURN);
      }

      let pokemonCard: PokemonCard | undefined;

      switch (action.target.slot) {
        case SlotType.ACTIVE:
        case SlotType.BENCH: {
          const target = StateUtils.getTarget(state, player, action.target);
          pokemonCard = target.getPokemonCard();
          if((pokemonCard as any)?._wotcRevealAction&&action.name==='Reveal face-down card'){revealWotcSlot(store,state,target);return checkState(store,state);}
          break;
        }
        case SlotType.DISCARD: {
          const discardCard = player.discard.cards[action.target.index];
          if (discardCard instanceof PokemonCard) {
            pokemonCard = discardCard;
          }
          break;
        }
        case SlotType.HAND: {
          const handCard = player.hand.cards[action.target.index];
          if (handCard instanceof PokemonCard) {
            pokemonCard = handCard;
          }
          break;
        }
      }

      if (pokemonCard !== undefined) {
        // Always resolve powers through CheckPokemonPowersEffect so ability locks
        // (Hex Maniac, Silent Lab, Garbodor, etc.) can filter the list. Do not merge
        // raw pokemonCard.powers — that bypasses Check filters.
        const powersEffect = new CheckPokemonPowersEffect(player, pokemonCard);
        state = store.reduceEffect(state, powersEffect);
        const power = powersEffect.powers.find(a => a.name === action.name);

        if (power === undefined) {
          throw new GameError(GameMessage.UNKNOWN_POWER);
        }

        const slot = action.target.slot;
        if (slot === SlotType.ACTIVE || slot === SlotType.BENCH) {
          if (!power.useWhenInPlay) {
            throw new GameError(GameMessage.CANNOT_USE_POWER);
          }
        }

        if (slot === SlotType.HAND && !power.useFromHand) {
          throw new GameError(GameMessage.CANNOT_USE_POWER);
        }

        if (slot === SlotType.DISCARD && !power.useFromDiscard) {
          throw new GameError(GameMessage.CANNOT_USE_POWER);
        }

        state = store.reduceEffect(state, new UsePowerEffect(player, power, pokemonCard, action.target));
        return state;
      }
    }

    if (action instanceof UseTrainerAbilityAction) {
      const player = state.players[state.activePlayer];

      if (player === undefined || player.id !== action.clientId) {
        throw new GameError(GameMessage.NOT_YOUR_TURN);
      }

      let trainerCard: TrainerCard | undefined;

      switch (action.target.slot) {
        case SlotType.DISCARD: {
          const discardCard = player.discard.cards[action.target.index];
          if (discardCard instanceof TrainerCard) {
            trainerCard = discardCard;
          }
          break;
        }
        case SlotType.HAND: {
          const handCard = player.hand.cards[action.target.index];
          if (handCard instanceof TrainerCard) {
            trainerCard = handCard;
          }
          break;
        }
      }

      if (trainerCard !== undefined) {
        const power = trainerCard.powers.find(a => a.name === action.name);

        if (power === undefined) {
          throw new GameError(GameMessage.UNKNOWN_POWER);
        }

        const slot = action.target.slot;

        if (slot === SlotType.DISCARD && !power.useFromDiscard) {
          throw new GameError(GameMessage.CANNOT_USE_POWER);
        }

        if (slot === SlotType.HAND && !power.useFromHand) {
          throw new GameError(GameMessage.CANNOT_USE_POWER);
        }

        state = store.reduceEffect(state, new UseTrainerPowerEffect(player, power, trainerCard, action.target));
        return state;
      }
    }

    if (action instanceof UseEnergyAbilityAction) {
      const player = state.players[state.activePlayer];

      if (player === undefined || player.id !== action.clientId) {
        throw new GameError(GameMessage.NOT_YOUR_TURN);
      }

      let energyCard: EnergyCard | undefined;

      const discardCard = player.discard.cards[action.target.index];
      if (discardCard instanceof EnergyCard) {
        energyCard = discardCard;

        if (energyCard !== undefined) {
          let power;
          if (action.target.slot === SlotType.DISCARD) {
            power = energyCard.powers.find(a => a.name === action.name);
          }

          if (power === undefined) {
            throw new GameError(GameMessage.UNKNOWN_POWER);
          }

          const slot = action.target.slot;

          if (slot === SlotType.DISCARD && !power.useFromDiscard) {
            throw new GameError(GameMessage.CANNOT_USE_POWER);
          }

          state = store.reduceEffect(state, new UseEnergyPowerEffect(player, power, energyCard, action.target));
          return state;
        }
      }
    }

    if (action instanceof UseStadiumAction) {
      const player = state.players[state.activePlayer];

      if (player === undefined || player.id !== action.clientId) {
        throw new GameError(GameMessage.NOT_YOUR_TURN);
      }

      if (player.stadiumUsedTurn === state.turn && !(StateUtils.getStadiumCard(state) as any)?._wotcUnlimitedStadiumAction) {
        throw new GameError(GameMessage.STADIUM_ALREADY_USED);
      }

      const stadium = StateUtils.getStadiumCard(state);
      if (stadium === undefined) {
        throw new GameError(GameMessage.NO_STADIUM_IN_PLAY);
      }
      state = store.reduceEffect(state, new UseStadiumEffect(player, stadium));
      return state;
    }
  }
  return state;
}
