import { PokemonCard } from '../../../game/store/card/pokemon-card';
import { Stage, CardType } from '../../../game/store/card/card-types';

export class Makuhita extends PokemonCard {
  public stage: Stage = Stage.BASIC;
  public cardType: CardType[] = [F];
  public hp: number = 80;
  public weakness = [{ type: P }];
  public retreat = [C, C, C];

  public attacks = [{
    name: 'Punch',
    cost: [F],
    damage: 10,
    text: ''
  },
  {
    name: 'Strength',
    cost: [F, C, C],
    damage: 40,
    text: ''
  }];

  public set: string = 'FFI';
  public setNumber: string = '51';
  public cardImage: string = 'assets/cardback.png';
  public name: string = 'Makuhita';
  public fullName: string = 'Makuhita FFI';
}
