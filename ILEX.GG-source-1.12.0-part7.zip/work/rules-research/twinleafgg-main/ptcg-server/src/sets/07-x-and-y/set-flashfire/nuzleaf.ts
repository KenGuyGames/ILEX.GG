import { PokemonCard } from '../../../game/store/card/pokemon-card';
import { Stage, CardType } from '../../../game/store/card/card-types';

export class Nuzleaf extends PokemonCard {
  public stage: Stage = Stage.STAGE_1;
  public evolvesFrom = 'Seedot';
  public cardType: CardType[] = [G];
  public hp: number = 80;
  public weakness = [{ type: R }];
  public retreat = [C];

  public attacks = [{
    name: 'Razor Leaf',
    cost: [C],
    damage: 20,
    text: ''
  },
  {
    name: 'Cut',
    cost: [G, C, C],
    damage: 40,
    text: ''
  }];

  public set: string = 'FLF';
  public setNumber: string = '6';
  public cardImage: string = 'assets/cardback.png';
  public name: string = 'Nuzleaf';
  public fullName: string = 'Nuzleaf FLF';
}
