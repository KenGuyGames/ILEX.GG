import { PokemonCard } from '../../../game/store/card/pokemon-card';
import { Stage, CardType, CardTag } from '../../../game/store/card/card-types';
import { StoreLike } from '../../../game/store/store-like';
import { State } from '../../../game/store/state/state';
import { Effect } from '../../../game/store/effects/effect';
import { PowerType } from '../../../game/store/card/pokemon-types';
import { StateUtils } from '../../../game/store/state-utils';
import { IS_ABILITY_BLOCKED, WAS_ATTACK_USED } from '../../../game/store/prefabs/prefabs';

export class Hawlucha extends PokemonCard {
  public stage: Stage = Stage.BASIC;

  public cardType: CardType[] = [CardType.FIGHTING];

  public hp: number = 70;

  public weakness = [{ type: CardType.LIGHTNING }];

  public resistance = [{ type: CardType.FIGHTING, value: -20 }];

  public retreat = [];

  public powers = [
    {
      name: 'Shining Spirit',
      powerType: PowerType.ABILITY,
      text: "Damage from this Pokémon's attacks isn't affected by " + 'Weakness or Resistance.',
    },
  ];

  public attacks = [
    {
      name: 'Flying Press',
      cost: [CardType.FIGHTING],
      damage: 60,
      text: "If your opponent's Active Pokemon isn't a Pokemon-EX, " + 'this attack does nothing.',
    },
  ];

  public set: string = 'FFI';

  public name: string = 'Hawlucha';

  public fullName: string = 'Hawlucha FFI';

  public cardImage: string = 'assets/cardback.png';

  public setNumber: string = '63';

  public reduceEffect(store: StoreLike, state: State, effect: Effect): State {
    if (WAS_ATTACK_USED(effect, 0, this)) {
      const player = effect.player;
      const opponent = StateUtils.getOpponent(state, player);

      const defending = opponent.active.getPokemonCard();
      if (!defending || !defending.hasTag(CardTag.POKEMON_EX)) {
        effect.damage = 0;
        return state;
      }

      // Ability - ignore weakness and resistance for this attack.
      // Try to reduce PowerEffect, to check if something is blocking our ability
      if (IS_ABILITY_BLOCKED(store, state, player, this)) {
        return state;
      }

      effect.ignoreWeakness = true;
      effect.ignoreResistance = true;
    }

    return state;
  }
}
