import { PokemonCard } from '../../../game/store/card/pokemon-card';
import { Stage, CardType } from '../../../game/store/card/card-types';

export class Kangaskhan extends PokemonCard {
  public stage: Stage = Stage.BASIC;
  public cardType: CardType[] = [C];
  public hp: number = 120;
  public weakness = [{ type: F }];
  public retreat = [C, C, C];

  public attacks = [{
    name: 'Tiny Punch',
    cost: [C, C],
    damage: 40,
    text: ''
  },
  {
    name: 'Mega Punch',
    cost: [C, C, C, C],
    damage: 100,
    text: ''
  }];

  public set: string = 'FCO';
  public setNumber: string = '75';
  public cardImage: string = 'assets/cardback.png';
  public name: string = 'Kangaskhan';
  public fullName: string = 'Kangaskhan FCO';
}
