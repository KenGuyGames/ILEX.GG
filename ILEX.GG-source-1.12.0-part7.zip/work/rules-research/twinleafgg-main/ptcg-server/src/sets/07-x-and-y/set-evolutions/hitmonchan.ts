import { PokemonCard } from '../../../game/store/card/pokemon-card';
import { Stage, CardType } from '../../../game/store/card/card-types';

export class Hitmonchan extends PokemonCard {
  public stage: Stage = Stage.BASIC;
  public cardType: CardType[] = [F];
  public hp: number = 90;
  public weakness = [{ type: P }];
  public retreat = [C, C];

  public attacks = [{
    name: 'Jab',
    cost: [F],
    damage: 30,
    text: ''
  },
  {
    name: 'Special Punch',
    cost: [F, F, C],
    damage: 90,
    text: ''
  }];

  public set: string = 'EVO';
  public setNumber: string = '62';
  public cardImage: string = 'assets/cardback.png';
  public name: string = 'Hitmonchan';
  public fullName: string = 'Hitmonchan EVO';
}
