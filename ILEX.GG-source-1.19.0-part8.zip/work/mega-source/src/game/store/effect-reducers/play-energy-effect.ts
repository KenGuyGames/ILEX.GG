import { AttachEnergyEffect, AfterEnergyAttachedEffect } from '../effects/play-card-effects';
import { GameError } from '../../game-error';
import { RESOLVE_PENDING_ENERGY_ATTACH_DAMAGE_COUNTERS } from '../prefabs/attack-effects';
import { GameMessage, GameLog } from '../../game-message';
import { Effect } from '../effects/effect';
import { State } from '../state/state';
import { StoreLike } from '../store-like';
import { EnergyType, SpecialCondition } from '../card/card-types';
import { SlotType } from '../actions/play-card-action';
import { EndTurnEffect } from '../effects/game-phase-effects';

/**
 * Helper function to emit animation events
 */
function emitAnimationEvent(store: StoreLike, eventName: string, data: {
  playerId: number;
  cardId: number | string;
  slot?: string;
  index?: number;
}): void {
  const game = (store as any).handler;
  if (game && game.core && typeof game.core.emit === 'function') {
    game.core.emit((c: any) => {
      if (typeof c.socket !== 'undefined') {
        c.socket.emit(`game[${game.id}]:${eventName}`, data);
      }
    });
  }
}

export function playEnergyReducer(store: StoreLike, state: State, effect: Effect): State {


  /* Play energy card */
  if (effect instanceof AttachEnergyEffect) {
    const pokemonCard = effect.target.getPokemonCard();
    if (pokemonCard === undefined) {
      throw new GameError(GameMessage.INVALID_TARGET);
    }
    if (effect.player.cannotPlayEnergyCards) {
      throw new GameError(GameMessage.BLOCKED_BY_EFFECT);
    }
    if (effect.energyCard.energyType === EnergyType.SPECIAL
      && effect.player.cannotPlaySpecialEnergyCards) {
      throw new GameError(GameMessage.BLOCKED_BY_EFFECT);
    }

    const fromHand = effect.player.hand.cards.includes(effect.energyCard);
    if ((effect.target as any).wotcAllEnergyLockUntilTurn === state.turn && effect.target.marker.hasMarker('WOTC_ALL_ENERGY_LOCK')) throw new GameError(GameMessage.BLOCKED_BY_EFFECT);
    if (fromHand && effect.target === effect.player.active
      && (effect.player as any).wotcActiveHandEnergyLockUntilTurn === state.turn) {
      throw new GameError(GameMessage.BLOCKED_BY_EFFECT);
    }
    if (fromHand && effect.target.cannotAttachEnergyFromHandNextTurn) {
      throw new GameError(GameMessage.BLOCKED_BY_EFFECT);
    }

    if (fromHand && effect.target.pendingEnergyAttachDamageCounters) {
      state = RESOLVE_PENDING_ENERGY_ATTACH_DAMAGE_COUNTERS(store, state, effect);
    }

    store.log(state, GameLog.LOG_PLAYER_ATTACHES_CARD, {
      name: effect.player.name,
      card: effect.energyCard.name,
      pokemon: pokemonCard.name
    });
    // Move card to main PokemonCardList first (so it's in the cards array)
    const source=(effect as any).source||effect.player.hand;
    if((effect as any).source&&!source.cards.includes(effect.energyCard))throw new GameError(GameMessage.INVALID_TARGET);
    source.moveCardTo(effect.energyCard, effect.target);
    // Then also add it to the energies CardList
    if (!effect.target.energies.cards.includes(effect.energyCard)) {
      effect.target.energies.cards.push(effect.energyCard);
    }

    // Derive slot and index for animation/sound event
    const slot = effect.target === effect.player.active ? SlotType.ACTIVE : SlotType.BENCH;
    const index = slot === SlotType.BENCH ? effect.player.bench.indexOf(effect.target) : undefined;
    emitAnimationEvent(store, 'attachEnergy', {
      playerId: effect.player.id,
      cardId: effect.energyCard.id,
      slot: String(slot),
      index
    });

    state = store.reduceEffect(state, new AfterEnergyAttachedEffect(effect.player, effect.energyCard, effect.target, fromHand,effect.origin));

    if (fromHand && effect.target.pendingEnergyAttachFromHandConsequence) {
      const consequence = effect.target.pendingEnergyAttachFromHandConsequence;
      if (consequence.asleep) {
        effect.target.addSpecialCondition(SpecialCondition.ASLEEP);
      }
      if (consequence.endTurn) {
        state = store.reduceEffect(state, new EndTurnEffect(effect.player));
      }
    }

    return state;
  }

  return state;
}
