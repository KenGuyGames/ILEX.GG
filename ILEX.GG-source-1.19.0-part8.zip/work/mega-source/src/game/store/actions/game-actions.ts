import { Action } from './action';
import { CardTarget } from './play-card-action';

export class AttackAction implements Action {

  readonly type: string = 'ATTACK_ACTION';

  constructor(
    public clientId: number,
    public name: string,
    public sourceTarget?: CardTarget
  ) { }

}

export class UseAbilityAction implements Action {

  readonly type: string = 'USE_ABILITY_ACTION';

  constructor(
    public clientId: number,
    public name: string,
    public target: CardTarget
  ) { }

}

export class UseTrainerAbilityAction implements Action {

  readonly type: string = 'USE_TRAINER_ABILITY_ACTION';

  constructor(
    public clientId: number,
    public name: string,
    public target: CardTarget
  ) { }

}

export class UseEnergyAbilityAction implements Action {

  readonly type: string = 'USE_ENERGY_ABILITY_ACTION';

  constructor(
    public clientId: number,
    public name: string,
    public target: CardTarget
  ) { }

}

export class UseStadiumAction implements Action {

  readonly type: string = 'USE_STADIUM_ACTION';

  constructor(
    public clientId: number
  ) { }

}

export class RetreatAction implements Action {

  readonly type: string = 'RETREAT_ACTION';

  constructor(
    public clientId: number,
    public benchIndex: number
  ) { }

}

export class RetreatStartAction implements Action {

  readonly type: string = 'RETREAT_START_ACTION';

  constructor(public clientId: number) { }

}

export class PassTurnAction implements Action {

  readonly type: string = 'PASS_TURN';

  constructor(public clientId: number) { }

}
