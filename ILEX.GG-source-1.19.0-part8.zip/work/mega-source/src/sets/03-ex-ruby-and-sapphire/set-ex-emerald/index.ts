import { Card } from '../../../game';
import { GrassEnergy, FireEnergy, WaterEnergy, LightningEnergy, PsychicEnergy, FightingEnergy } from './basic-energies';
import { Feebas } from './feebas';
import { Loudred } from './loudred';
import { LumBerry } from './lum-berry';
import { Medichamex } from './medicham-ex';
import { Meditite } from './meditite';
import { ProfessorBirch } from './professor-birch';
import { Scott } from './scott';
import { Treecko } from './treecko';
import { Voltorb } from './voltorb';

// Other prints
import {
  DarknessEnergySpecialEM,
  DoubleRainbowEnergyEM,
  MetalEnergySpecialEM,
  MultiEnergyEM,
  RareCandyEM,
  WallysTrainingEM,
} from './other-prints';

export const setEXEmerald: Card[] = [
  new Feebas(),
  new Loudred(),
  new LumBerry(),
  new Medichamex(),
  new Meditite(),
  new ProfessorBirch(),
  new Scott(),
  new Treecko(),
  new Voltorb(),

  // Other prints
  new DarknessEnergySpecialEM(),
  new DoubleRainbowEnergyEM(),
  new MetalEnergySpecialEM(),
  new MultiEnergyEM(),
  new RareCandyEM(),
  new WallysTrainingEM(),

  // Basic energies
  new GrassEnergy(),
  new FireEnergy(),
  new WaterEnergy(),
  new LightningEnergy(),
  new PsychicEnergy(),
  new FightingEnergy(),
];