import { PokemonCard, Stage, CardType, StoreLike, State, PowerType } from '../../../game';
import { Effect } from '../../../game/store/effects/effect';
import { CheckRetreatCostEffect, CheckProvidedEnergyEffect } from '../../../game/store/effects/check-effects';
import { IS_POKEBODY_BLOCKED, WAS_ATTACK_USED, COIN_FLIP_PROMPT } from '../../../game/store/prefabs/prefabs';

export class Lombre extends PokemonCard {
  public stage: Stage = Stage.STAGE_1;
  public evolvesFrom = 'Lotad';
  public cardType: CardType[] = [W];
  public hp: number = 70;
  public weakness = [{ type: L }];
  public retreat = [C];

  public powers = [{
    name: 'Aqua Lift',
    powerType: PowerType.POKEBODY,
    text: 'If Lombre has any [W] Energy attached to it, the Retreat Cost for Lombre is 0.'
  }];

  public attacks = [{
    name: 'Ambush',
    cost: [C, C],
    damage: 20,
    damageCalculation: '+',
    text: 'Flip a coin. If heads, this attack does 20 damage plus 20 more damage.'
  }];

  public set: string = 'DX';
  public setNumber: string = '33';
  public cardImage: string = 'assets/cardback.png';
  public name: string = 'Lombre';
  public fullName: string = 'Lombre DX';

  public reduceEffect(store: StoreLike, state: State, effect: Effect): State {
    // Aqua Lift
    if (effect instanceof CheckRetreatCostEffect && effect.target.cards.includes(this)) {
      const player = effect.player;
      const pokemonCard = effect.target.getPokemonCard();

      if (pokemonCard !== this) {
        return state;
      }

      // Try to reduce PowerEffect, to check if something is blocking our ability
      if (IS_POKEBODY_BLOCKED(store, state, player, this)) {
        return state;
      }

      const checkProvidedEnergy = new CheckProvidedEnergyEffect(player, effect.target);
      state = store.reduceEffect(state, checkProvidedEnergy);

      // Check if there is any Water energy attached
      const hasWaterEnergy = checkProvidedEnergy.energyMap.some(energy =>
        energy.provides.includes(CardType.WATER) || energy.provides.includes(CardType.ANY)
      );

      if (hasWaterEnergy) {
        effect.cost = [];
      }
    }

    // Ambush
    if (WAS_ATTACK_USED(effect, 0, this)) {
      const player = effect.player;

      // Flip a coin
      state = COIN_FLIP_PROMPT(store, state, player, result => {
        if (result) {
          effect.damage += 20; // 20 base + 20 for heads
        }
        return state;
      });
    }

    return state;
  }
} 