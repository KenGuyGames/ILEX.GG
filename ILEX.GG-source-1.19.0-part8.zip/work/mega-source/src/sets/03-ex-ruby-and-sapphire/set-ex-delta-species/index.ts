import { Card } from '../../../game/store/card/card';
import { Bagon } from './bagon';
import { Bagon2 } from './bagon2';
import { Beldum } from './beldum';
import { Crobat } from './crobat';
import { Ditto } from './ditto';
import { Dragonair } from './dragonair';
import { Dragonair2 } from './dragonair2';
import { Dragonite } from './dragonite';
import { Dratini } from './dratini';
import { Dratini2 } from './dratini2';
import { Eevee } from './eevee';
import { Eevee2 } from './eevee2';
import { Flareonex } from './flareon-ex';
import { Gardevoir } from './gardevoir';
import { GroudonStar } from './groudon-star';
import { HolonEnergyFF } from './holon-energy-ff';
import { HolonFarmer } from './holon-farmer';
import { HolonLass } from './holon-lass';
import { HolonMentor } from './holon-mentor';
import { HolonRuins } from './holon-ruins';
import { HolonScientist } from './holon-scientist';
import { HolonTransceiver } from './holon-transceiver';
import { HolonResearcher } from './holon-researcher';
import { HolonsElectrode } from './holons-electrode';
import { HolonsMagnemite } from './holons-magnemite';
import { HolonsMagneton } from './holons-magneton';
import { HolonsVoltorb } from './holons-voltorb';
import { Jolteonex } from './jolteon-ex';
import { Kirlia } from './kirlia';
import { Koffing } from './koffing';
import { Larvitar } from './larvitar';
import { Magnemite } from './magnemite';
import { Marowak } from './marowak';
import { Meowth } from './meowth';
import { Metagross } from './metagross';
import { Metang } from './metang';
import { Mewtwo } from './mewtwo';
import { Persian } from './persian';
import { Porygon } from './porygon';
import { Porygon2 } from './porygon2';
import { Ralts } from './ralts';
import { Rayquaza } from './rayquaza';
import { Salamence } from './salamence';
import { Shelgon } from './shelgon';
import { Shelgon2 } from './shelgon2';
import { Vaporeonex } from './vaporeon-ex';
import { Weezing } from './weezing';
import { Zubat } from './zubat';

import { SuperScoopUpDS, DarknessEnergySpecialDS, GreatBallDS, MetalEnergySpecialDS, DualBallDS } from './other-prints';

export const setEXDeltaSpecies: Card[] = [
  new Bagon(),
  new Bagon2(),
  new Beldum(),
  new Crobat(),
  new Ditto(),
  new Dragonair(),
  new Dragonair2(),
  new Dragonite(),
  new Dratini(),
  new Dratini2(),
  new Eevee(),
  new Eevee2(),
  new Flareonex(),
  new Gardevoir(),
  new GroudonStar(),
  new HolonEnergyFF(),
  new HolonFarmer(),
  new HolonLass(),
  new HolonMentor(),
  new HolonRuins(),
  new HolonScientist(),
  new HolonTransceiver(),
  new HolonResearcher(),
  new HolonsElectrode(),
  new HolonsMagnemite(),
  new HolonsMagneton(),
  new HolonsVoltorb(),
  new Jolteonex(),
  new Kirlia(),
  new Koffing(),
  new Larvitar(),
  new Magnemite(),
  new Marowak(),
  new Meowth(),
  new Metagross(),
  new Metang(),
  new Mewtwo(),
  new Persian(),
  new Porygon(),
  new Porygon2(),
  new Ralts(),
  new Rayquaza(),
  new Salamence(),
  new Shelgon(),
  new Shelgon2(),
  new Vaporeonex(),
  new Weezing(),
  new Zubat(),

  // Other Prints
  new DarknessEnergySpecialDS(),
  new GreatBallDS(),
  new MetalEnergySpecialDS(),
  new DualBallDS(),
  new SuperScoopUpDS(),
];
