import { Yveltal } from '../set-steam-siege/yveltal';
import { Xerneas } from '../set-steam-siege/xerneas';
import { GreatBall } from '../../03-ex-ruby-and-sapphire/set-ex-firered-leafgreen/great-ball';
import { MaxRevive } from '../set-generations/max-revive';
import { RedCard } from '../set-generations/red-card';
import { TeamFlareGrunt } from '../set-generations/team-flare-grunt';
import { RainbowEnergyPL } from '../../04-diamond-pearl-platinum/set-platinum/other-prints';
import { YveltalEx as YveltalExXY79 } from './yveltal-ex';
import { XerneasEX as XerneasEXXY97 } from './xerneas-ex';
import { Venipede } from '../../06-black-and-white/set-black-and-white/venipede';
import { VenusaurEx } from './venusaur-ex';
import { BlastoiseEx } from './blastoise-ex';
import { EmolgaEx } from './emolga-ex';
import { SkarmoryEx } from './skarmory-ex';
import { DoubleColorlessEnergy } from '../../set-base-set/double-colorless-energy';

export class YveltalXY extends Yveltal {
  public setNumber = '78';
  public fullName: string = 'Yveltal XY';
  public set = 'XY';
}

export class XerneasXY extends Xerneas {
  public setNumber = '96';
  public fullName: string = 'Xerneas XY';
  public set = 'XY';
}

export class GreatBallXY extends GreatBall {
  public setNumber = '118';
  public fullName: string = 'Great Ball XY';
  public set = 'XY';
}

export class MaxReviveXY extends MaxRevive {
  public setNumber = '120';
  public fullName: string = 'Max Revive XY';
  public set = 'XY';
}

export class RedCardXY extends RedCard {
  public setNumber = '124';
  public fullName: string = 'Red Card XY';
  public set = 'XY';
}

export class TeamFlareGruntXY extends TeamFlareGrunt {
  public setNumber = '129';
  public fullName: string = 'Team Flare Grunt XY';
  public set = 'XY';
}

export class DoubleColorlessEnergyXY extends DoubleColorlessEnergy {
  public set: string = 'XY';
  public fullName = 'Double Colorless Energy XY';
  public setNumber: string = '130';
}

export class RainbowEnergyPLXY extends RainbowEnergyPL {
  public setNumber = '131';
  public fullName: string = 'Rainbow Energy XY';
  public set = 'XY';
}

export class YveltalEx2XY extends YveltalExXY79 {
  public setNumber = '144';
  public fullName: string = 'Yveltal EX2 XY';
  public set = 'XY';
}

export class XerneasEX2XY extends XerneasEXXY97 {
  public setNumber = '146';
  public fullName: string = 'Xerneas-EX2 XY';
  public set = 'XY';
}

export class VenipedeXY extends Venipede {
  constructor(){super();this.hp=70;this.retreat=[C,C,C];this.attacks=this.attacks.map(a=>({...a,cost:[P,C],damage:20}));}
  public set: string = 'XY';
  public setNumber: string = '51';
  public fullName: string = 'Venipede XY';
}

export class VenusaurEx2 extends VenusaurEx {
  public set: string = 'XY';
  public setNumber: string = '141';
  public fullName: string = 'Venusaur-EX XY 141';
}

export class BlastoiseEx2 extends BlastoiseEx {
  public set: string = 'XY';
  public setNumber: string = '142';
  public fullName: string = 'Blastoise-EX XY 142';
}

export class EmolgaEx2 extends EmolgaEx {
  public set: string = 'XY';
  public setNumber: string = '143';
  public fullName: string = 'Emolga-EX XY 143';
}

export class SkarmoryEx2 extends SkarmoryEx {
  public set: string = 'XY';
  public setNumber: string = '145';
  public fullName: string = 'Skarmory-EX XY 145';
}
