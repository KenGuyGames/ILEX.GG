import {xyEnergyCards,xyEnergyView,xyDiscardEnergy,xyAfterAttack} from '../../../tcg-lab-xy-energy';
import { PokemonCard } from '../../../game/store/card/pokemon-card';
import { Stage, CardType, CardTag, SuperType } from '../../../game/store/card/card-types';
import { StoreLike, State, Card, ChooseCardsPrompt, GameMessage } from '../../../game';
import { Effect } from '../../../game/store/effects/effect';
import { COIN_FLIP_PROMPT, MOVE_CARDS, WAS_ATTACK_USED } from '../../../game/store/prefabs/prefabs';

export class GroudonEx extends PokemonCard {
  protected _tags = [CardTag.POKEMON_EX];
  public stage: Stage = Stage.BASIC;
  public cardType: CardType[] = [F];
  public hp: number = 180;
  public weakness = [{ type: G }];
  public retreat = [C, C, C, C];

  public attacks = [{
    name: 'Rip Claw',
    cost: [F, C],
    damage: 30,
    text: 'Flip a coin. If heads, discard an Energy attached to your opponent\'s Active Pokémon.'
  }, {
    name: 'Massive Rend',
    cost: [F, F, F, C],
    damage: 130,
    text: ''
  }];

  public set: string = 'PRC';
  public name: string = 'Groudon-EX';
  public fullName: string = 'Groudon EX PRC';
  public cardImage: string = 'assets/cardback.png';
  public setNumber: string = '85';

  public reduceEffect(store: StoreLike, state: State, effect: Effect): State {
    // Rip Claw
    const completed=xyAfterAttack(effect,0,this);
    if(completed){effect=completed;
      const player = effect.player;
      const opponent = effect.opponent;

      COIN_FLIP_PROMPT(store, state, player, (result) => {
        if (result) {
          if (!xyEnergyCards(opponent.active).some((c) => c.superType === SuperType.ENERGY)) {
            return state;
          }

          let cards: Card[] = [];
          return store.prompt(
            state,
            new ChooseCardsPrompt(
              player,
              GameMessage.CHOOSE_CARD_TO_DISCARD,
              opponent.active,
              { superType: SuperType.ENERGY },
              { min: 1, max: 1, allowCancel: false },
            ),
            (selected) => {
              cards = selected;

              xyDiscardEnergy(store,state,opponent.active,cards,this,effect);
            },
          );
        }
      });
    }

    return state;
  }
}
