import { PokemonCard } from '../../game/store/card/pokemon-card';
import { Stage, CardType } from '../../game/store/card/card-types';

export class Jigglypuff extends PokemonCard {
  public stage: Stage = Stage.BASIC;
  public cardType: CardType[] = [Y];
  public hp: number = 70;
  public weakness = [{ type: M }];
  public resistance = [{ type: D, value: -20 }];
  public retreat = [C];

  public attacks = [{
    name: 'Singing Voice',
    cost: [Y],
    damage: 10,
    text: ''
  },
  {
    name: 'Rollout',
    cost: [Y, C],
    damage: 30,
    text: ''
  }];

  public set: string = 'HIF';
  public setNumber: string = '41';
  public cardImage: string = 'assets/cardback.png';
  public name: string = 'Jigglypuff';
  public fullName: string = 'Jigglypuff HIF';
}
