import { Blastoise } from '../set-boundaries-crossed/blastoise';
import { Caitlin } from '../../09-sword-and-shield/set-chilling-reign/caitlin';
import { EnergyRetrieval } from '../../set-base-set/energy-retrieval';
import { PlumeFossil } from '../set-noble-victories/plume-fossil';
import { PokemonCatcher } from '../../10-scarlet-and-violet/set-scarlet-and-violet/pokemon-catcher';
import { RareCandy } from '../../03-ex-ruby-and-sapphire/set-ex-holon-phantoms/rare-candy';
import { PlasmaEnergy } from '../set-plasma-storm/plasma-energy';
import { VirizionEX as VirizionEXPLB9 } from './virizion-ex';
import { GenesectEX as GenesectEXPLB11 } from './genesect-ex';
import { JirachiEX as JirachiEXPLB60 } from './jirachi-ex';
import { PalkiaEX as PalkiaEXPLB66 } from './palkia-ex';
import { Exeggcute } from '../set-plasma-freeze/exeggcute';
import { Dusknoir } from '../set-boundaries-crossed/dusknoir';
import { RareCandy as RareCandyHP90 } from '../../03-ex-ruby-and-sapphire/set-ex-holon-phantoms/rare-candy';
import { UltraBall } from '../../10-scarlet-and-violet/set-scarlet-and-violet/ultra-ball';
import { MasterBall } from '../../10-scarlet-and-violet/set-temporal-forces/master-ball';
import { ProfessorJuniper } from '../set-black-and-white/professor-juniper';
import { ScoopUpCyclone } from '../../10-scarlet-and-violet/set-twilight-masquerade/scoop-up-cyclone';
import { CoverFossil } from '../set-noble-victories/cover-fossil';
import { DialgaEx } from './dialga-ex';
import { Iris } from './iris';
import { Virizion } from '../set-noble-victories/virizion';

export class ScoopUpCyclonePLB extends ScoopUpCyclone {
  public set = 'PLB';
  public setNumber = '95';
  public fullName: string = 'Scoop Up Cyclone PLB';
}

export class UltraBallPLB extends UltraBall {
  public set = 'PLB';
  public setNumber = '90';
  public fullName: string = 'Ultra ball PLB';
}

export class MasterBallPLB extends MasterBall {
  public set = 'PLB';
  public setNumber = '94';
  public fullName: string = 'Master Ball PLB';
}

export class ProfessorJuniperPLB extends ProfessorJuniper {
  public set = 'PLB';
  public setNumber = '84';
  public fullName: string = 'Professor Juniper PLB';
}
export class BlastoisePLB extends Blastoise {
  public setNumber = '16';
  public fullName: string = 'Blastoise PLB';
  public set = 'PLB';
}

export class CaitlinPLB extends Caitlin {
  public setNumber = '78';
  public fullName: string = 'Caitlin PLB';
  public set = 'PLB';
}

export class EnergyRetrievalPLB extends EnergyRetrieval {
  public setNumber = '80';
  public fullName: string = 'Energy Retrieval PLB';
  public set = 'PLB';
}

export class PlumeFossilPLB extends PlumeFossil {
  public setNumber = '82';
  public fullName: string = 'Plume Fossil PLB';
  public set = 'PLB';
}

export class PokemonCatcherPLB extends PokemonCatcher {
  public setNumber = '83';
  public fullName: string = 'Pokemon Catcher PLB';
  public set = 'PLB';
}

export class RareCandyPLB extends RareCandy {
  public setNumber = '85';
  public fullName: string = 'Rare Candy PLB';
  public set = 'PLB';
}

export class PlasmaEnergyPLB extends PlasmaEnergy {
  public setNumber = '91';
  public fullName: string = 'Plasma Energy PLB';
  public set = 'PLB';
}

export class VirizionEX2PLB extends VirizionEXPLB9 {
  public setNumber = '96';
  public fullName: string = 'Virizion EX2 PLB';
  public set = 'PLB';
}

export class GenesectEX2PLB extends GenesectEXPLB11 {
  public setNumber = '97';
  public fullName: string = 'Genesect EX2 PLB';
  public set = 'PLB';
}

export class JirachiEX2PLB extends JirachiEXPLB60 {
  public setNumber = '98';
  public fullName: string = 'Jirachi EX2 PLB';
  public set = 'PLB';
}

export class PalkiaEX2PLB extends PalkiaEXPLB66 {
  public setNumber = '100';
  public fullName: string = 'Palkia EX2 PLB';
  public set = 'PLB';
}

export class ExeggcutePLB extends Exeggcute {
  public setNumber = '102';
  public fullName: string = 'Exeggcute PLB';
  public set = 'PLB';
}

export class DusknoirPLB extends Dusknoir {
  public setNumber = '104';
  public fullName: string = 'Dusknoir PLB';
  public set = 'PLB';
}

export class RareCandy2PLB extends RareCandyHP90 {
  public setNumber = '105';
  public fullName: string = 'Rare Candy2 PLB';
  public set = 'PLB';
}

export class CoverFossilPLB extends CoverFossil {
  public set: string = 'PLB';
  public setNumber: string = '79';
  public fullName: string = 'Cover Fossil PLB';
}

export class DialgaEx2 extends DialgaEx {
  public set: string = 'PLB';
  public setNumber: string = '99';
  public fullName: string = 'Dialga-EX PLB 99';
}

export class Iris2 extends Iris {
  public set: string = 'PLB';
  public setNumber: string = '101';
  public fullName: string = 'Iris PLB 101';
}

export class VirizionPLB extends Virizion {
  public set: string = 'PLB';
  public setNumber: string = '103';
  public fullName: string = 'Virizion PLB';
}
