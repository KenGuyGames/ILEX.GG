import { ADD_SLEEP_TO_PLAYER_ACTIVE, AFTER_ATTACK, WAS_ATTACK_USED } from '../../../game/store/prefabs/prefabs';
import { CardType, Stage } from '../../../game/store/card/card-types';
import { StateUtils } from '../../../game/store/state-utils';
import { AttackEffect } from '../../../game/store/effects/game-effects';
import { PokemonCard } from '../../../game/store/card/pokemon-card';
import { Effect } from '../../../game/store/effects/effect';
import { State, StoreLike, pokemonHasCardType } from '../../../game';
export class Cryogonal extends PokemonCard {
  public stage: Stage = Stage.BASIC;
  public cardType: CardType[] = [W];
  public hp: number = 80;
  public weakness = [{ type: M }];
  public retreat = [C];

  public attacks = [
    {
      name: 'Icy Wind',
      cost: [W],
      damage: 10,
      text: 'The Defending Pokémon is now Asleep.'
    },
    {
      name: 'Ice Shard',
      cost: [W, C],
      damage: 30,
      damageCalculation: '+',
      text: 'If the Defending Pokémon is a Fighting Pokémon, this attack does 40 more damage.'
    }
  ];

  public set: string = 'NVI';
  public cardImage: string = 'assets/cardback.png';
  public setNumber: string = '32';
  public name: string = 'Cryogonal';
  public fullName: string = 'Cryogonal NVI';

  public reduceEffect(store: StoreLike, state: State, effect: Effect): State {
    if (AFTER_ATTACK(effect, 0, this)) {
      ADD_SLEEP_TO_PLAYER_ACTIVE(store, state, effect.opponent, this);
    }

    if (WAS_ATTACK_USED(effect, 1, this)) {
      const player = effect.player;
      const opponent = StateUtils.getOpponent(state, player);
      const defendingPokemon = opponent.active.getPokemonCard();

      if (defendingPokemon && pokemonHasCardType(defendingPokemon, CardType.FIGHTING)) {
        (effect as AttackEffect).damage += 40;
      }
    }

    return state;
  }
}
