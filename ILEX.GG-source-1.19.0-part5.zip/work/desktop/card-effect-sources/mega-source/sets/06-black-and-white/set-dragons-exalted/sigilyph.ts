import {StateUtils as BwEnergyUnits} from '../../../game';
import { PokemonCard } from '../../../game/store/card/pokemon-card';
import { Stage, CardType, CardTag } from '../../../game/store/card/card-types';
import { StoreLike } from '../../../game/store/store-like';
import { State } from '../../../game/store/state/state';
import { Effect } from '../../../game/store/effects/effect';
import { PowerEffect } from '../../../game/store/effects/game-effects';
import { AbstractAttackEffect } from '../../../game/store/effects/attack-effects';
import { PowerType } from '../../../game/store/card/pokemon-types';
import { StateUtils } from '../../../game/store/state-utils';
import { CheckProvidedEnergyEffect } from '../../../game/store/effects/check-effects';
import { WAS_ATTACK_USED } from '../../../game/store/prefabs/prefabs';

export class Sigilyph extends PokemonCard {
  public stage: Stage = Stage.BASIC;

  public cardType: CardType[] = [CardType.PSYCHIC];

  public hp: number = 90;

  public weakness = [{ type: CardType.PSYCHIC }];

  public retreat = [CardType.COLORLESS];

  public powers = [
    {
      name: 'Safeguard',
      powerType: PowerType.ABILITY,
      text:
        'Prevent all effects of attacks, including damage, done to ' +
        'this Pokemon by Pokemon-EX.',
    },
  ];

  public attacks = [
    {
      name: 'Psychic',
      cost: [CardType.PSYCHIC, CardType.COLORLESS, CardType.COLORLESS],
      damage: 50,
      text: 'Does 10 more damage for each Energy attached to ' + 'the Defending Pokemon.',
    },
  ];

  public set: string = 'DRX';

  public name: string = 'Sigilyph';

  public fullName: string = 'Sigilyph DRX';

  public cardImage: string = 'assets/cardback.png';

  public setNumber: string = '52';

  public reduceEffect(store: StoreLike, state: State, effect: Effect): State {
    if (WAS_ATTACK_USED(effect, 0, this)) {
      const player = effect.player;
      const opponent = StateUtils.getOpponent(state, player);

      const checkProvidedEnergyEffect = new CheckProvidedEnergyEffect(opponent);
      store.reduceEffect(state, checkProvidedEnergyEffect);
      const energyCount = checkProvidedEnergyEffect.energyMap.reduce(
        (left, p) => left + BwEnergyUnits.getProvidesUnitCount(p.provides),
        0,
      );

      effect.damage += energyCount * 10;
    }

    // Prevent damage from Pokemon-EX
    if (effect instanceof AbstractAttackEffect && effect.target.cards.includes(this)) {
      const pokemonCard = effect.target.getPokemonCard();
      const sourceCard = effect.source.getPokemonCard();

      // pokemon is evolved
      if (pokemonCard !== this) {
        return state;
      }

      if (sourceCard && sourceCard.hasTag(CardTag.POKEMON_EX)) {
        // Try to reduce PowerEffect, to check if something is blocking our ability
        try {
          const player = StateUtils.findOwner(state, effect.target);
          const stub = new PowerEffect(
            player,
            {
              name: 'test',
              powerType: PowerType.ABILITY,
              text: '',
            },
            this,
          );
          store.reduceEffect(state, stub);
        } catch {
          return state;
        }

        effect.preventDefault = true;
      }
    }

    return state;
  }
}
