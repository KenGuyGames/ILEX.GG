import { PokemonCard } from '../../../game/store/card/pokemon-card';
import { Stage, CardType } from '../../../game/store/card/card-types';
import { StoreLike, State, StateUtils } from '../../../game';
import { Effect } from '../../../game/store/effects/effect';
import { WAS_ATTACK_USED } from '../../../game/store/prefabs/prefabs';

export class Scrafty extends PokemonCard {
  public stage: Stage = Stage.STAGE_1;
  public evolvesFrom = 'Scraggy';
  public cardType: CardType[] = [D];
  public hp: number = 90;
  public weakness = [{ type: F }];
  public resistance = [{ type: P, value: -20 }];
  public retreat = [C, C];

  public attacks = [
    {
      name: 'Rock Head',
      cost: [D],
      damage: 20,
      text: 'During your opponent\'s next turn, any damage done to this Pokémon by attacks is reduced by 20 (after applying Weakness and Resistance).'
    },
    {
      name: 'Hammer Kick',
      cost: [D, C, C],
      damage: 50,
      damageCalculation: '+',
      text: 'If this Pokémon has fewer remaining HP than the Defending Pokémon, this attack does 30 more damage.'
    }
  ];

  public set: string = 'NXD';
  public setNumber: string = '74';
  public cardImage: string = 'assets/cardback.png';
  public name: string = 'Scrafty';
  public fullName: string = 'Scrafty NXD';

  public reduceEffect(store: StoreLike, state: State, effect: Effect): State {
    if (WAS_ATTACK_USED(effect, 0, this)) {
      effect.player.active.damageReductionNextTurn = 20;
    }

    if (WAS_ATTACK_USED(effect, 1, this)) {
      const player = effect.player;
      const opponent = StateUtils.getOpponent(state, player);

      const myRemainingHP = this.hp - player.active.damage;
      const defenderCard = opponent.active.getPokemonCard();
      const defenderRemainingHP = defenderCard ? defenderCard.hp - opponent.active.damage : 0;

      if (myRemainingHP < defenderRemainingHP) {
        effect.damage += 30;
      }
    }

    return state;
  }
}
