import { Reshiram } from '../set-black-and-white/reshiram';
import { Zekrom } from '../set-black-and-white/zekrom';
import { Riolu } from '../set-legendary-treasures/riolu';
import { ExpShare } from '../../10-scarlet-and-violet/set-scarlet-and-violet/exp-share';
import { ShayminEX as ShayminEXNXD5 } from './shaymin-ex';
import { ReshiramEx as ReshiramExNXD22 } from './reshiram-ex';
import { ZekromEx as ZekromExNXD51 } from './zekrom-ex';
import { MewtwoEx as MewtwoExNXD54 } from './mewtwo-ex';
import { Emboar } from '../set-black-and-white/emboar';
import { Chandelure as ChandelureNVI60 } from '../set-noble-victories/chandelure';
import { Zoroark } from '../set-black-and-white/zoroark';
import { Hydreigon as HydreigonNVI79 } from '../set-noble-victories/hydreigon';
import { DoubleColorlessEnergy } from '../../set-base-set/double-colorless-energy';
import { KyuremEx as KyuremExNXD38 } from './kyurem-ex';
import { RegigigasEx as RegigigasExNXD82 } from './regigigas-ex';
import { LevelBall } from './level-ball';

export class DoubleColorlessEnergyNXD extends DoubleColorlessEnergy {
  public fullName = 'Double Colorless Energy NXD';
  public set = 'NXD';
  public setNumber = '92';
}

export class LevelBallNXD extends LevelBall {
  public fullName = 'Level Ball NXD';
  public set = 'NXD';
  public setNumber = '89';
}
export class ReshiramNXD extends Reshiram {
  public setNumber = '21';
  public fullName: string = 'Reshiram NXD';
  public set = 'NXD';
}

export class ZekromNXD extends Zekrom {
  public setNumber = '50';
  public fullName: string = 'Zekrom NXD';
  public set = 'NXD';
}

export class RioluNXD extends Riolu {
  public setNumber = '63';
  public fullName: string = 'Riolu NXD';
  public set = 'NXD';
}

export class ExpShareNXD extends ExpShare {
  public setNumber = '87';
  public fullName: string = 'Exp. Share NXD';
  public set = 'NXD';
}

export class ShayminEX2NXD extends ShayminEXNXD5 {
  public setNumber = '94';
  public fullName: string = 'Shaymin EX2 NXD';
  public set = 'NXD';
}

export class ReshiramEx2NXD extends ReshiramExNXD22 {
  public setNumber = '95';
  public fullName: string = 'Reshiram EX2 NXD';
  public set = 'NXD';
}

export class KyuremEx2NXD extends KyuremExNXD38 {
  public setNumber = '96';
  public fullName: string = 'Kyurem-EX NXD 96';
}

export class ZekromEx2NXD extends ZekromExNXD51 {
  public setNumber = '97';
  public fullName: string = 'Zekrom EX2 NXD';
  public set = 'NXD';
}

export class MewtwoEx2NXD extends MewtwoExNXD54 {
  public setNumber = '98';
  public fullName: string = 'Mewtwo EX2 NXD';
  public set = 'NXD';
}

export class RegigigasEx2NXD extends RegigigasExNXD82 {
  public setNumber = '99';
  public fullName: string = 'Regigigas-EX NXD 99';
}

export class EmboarNXD extends Emboar {
  public setNumber = '100';
  public fullName: string = 'Emboar NXD';
  public set = 'NXD';
}

export class Chandelure2NXD extends ChandelureNVI60 {
  public setNumber = '101';
  public fullName: string = 'Chandelure2 NXD';
  public set = 'NXD';
}

export class ZoroarkNXD extends Zoroark {
  public setNumber = '102';
  public fullName: string = 'Zoroark NXD';
  public set = 'NXD';
}

export class HydreigonNXD extends HydreigonNVI79 {
  public setNumber = '103';
  public fullName: string = 'Hydreigon NXD';
  public set = 'NXD';
}
