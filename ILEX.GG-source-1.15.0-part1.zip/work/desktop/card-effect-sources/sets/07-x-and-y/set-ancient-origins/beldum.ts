import { PokemonCard } from '../../../game/store/card/pokemon-card';
import { Stage, CardType } from '../../../game/store/card/card-types';

export class Beldum extends PokemonCard {
  public stage: Stage = Stage.BASIC;
  public cardType: CardType[] = [M];
  public hp: number = 60;
  public weakness = [{ type: R }];
  public resistance = [{ type: P, value: -20 }];
  public retreat = [C, C];

  public attacks = [{
    name: 'Ram',
    cost: [M],
    damage: 10,
    text: ''
  },
  {
    name: 'Spinning Attack',
    cost: [M, C, C],
    damage: 30,
    text: ''
  }];

  public set: string = 'AOR';
  public setNumber: string = '47';
  public cardImage: string = 'assets/cardback.png';
  public name: string = 'Beldum';
  public fullName: string = 'Beldum AOR';
}
