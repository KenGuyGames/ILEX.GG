import { GreatBall } from '../../03-ex-ruby-and-sapphire/set-ex-firered-leafgreen/great-ball';
import { MaxPotion } from '../../06-black-and-white/set-emerging-powers/max-potion';
import { PokemonCatcher } from '../../10-scarlet-and-violet/set-scarlet-and-violet/pokemon-catcher';
import { Potion } from '../../set-base-set/potion';
import { ProfessorSycamore } from '../set-x-and-y/professor-sycamore';
import { ManaphyEX as ManaphyEXBKP32 } from './manaphy-ex';
import { Skyla } from '../../06-black-and-white/set-boundaries-crossed/skyla';
import { Delinquent as DelinquentBKP98 } from './delinquent';
import { MistysDetermination } from '../set-evolutions/mistys-determination';
import { Tierno } from '../set-phantom-forces/tierno';
import { GyaradosEx } from './gyarados-ex';
import { MGyaradosEx } from './m-gyarados-ex';
import { EspeonEX } from './espeon-ex';
import { DarkraiEx } from './darkrai-ex';
import { ScizorEx } from './scizor-ex';
import { MScizorEx } from './m-scizor-ex';

export class GreatBallBKP extends GreatBall {
  public setNumber = '100';
  public fullName: string = 'Great Ball BKP';
  public set = 'BKP';
}

export class MaxPotionBKP extends MaxPotion {
  public setNumber = '103';
  public fullName: string = 'Max Potion BKP';
  public set = 'BKP';
}

export class PokemonCatcherBKP extends PokemonCatcher {
  public setNumber = '105';
  public fullName: string = 'Pokemon Catcher BKP';
  public set = 'BKP';
}

export class PotionBKP extends Potion {
  public setNumber = '106';
  public fullName: string = 'Potion BKP';
  public set = 'BKP';
}

export class ProfessorSycamoreBKP extends ProfessorSycamore {
  public setNumber = '107';
  public fullName: string = 'Professor Sycamore BKP';
  public set = 'BKP';
  public legacyFullName = '';
}

export class ManaphyEX2BKP extends ManaphyEXBKP32 {
  public setNumber = '116';
  public fullName: string = 'Manaphy EX2 BKP';
  public set = 'BKP';
}

export class SkylaBKP extends Skyla {
  public setNumber = '122';
  public fullName: string = 'Skyla BKP';
  public set = 'BKP';
}

export class Delinquent2BKP extends DelinquentBKP98 {
  public setNumber = '98a';
  public fullName: string = 'Delinquent2 BKP';
  public set = 'BKP';
}

export class Delinquent3BKP extends DelinquentBKP98 {
  public setNumber = '98b';
  public fullName: string = 'Delinquent3 BKP';
  public set = 'BKP';
}

export class ProfessorSycamoreBKPa extends ProfessorSycamore {
  public setNumber = '107a';
  public fullName: string = 'Professor Sycamore2 BKP';
  public set = 'BKP';
  public legacyFullName = '';
}

export class MistysDeterminationBKP extends MistysDetermination {
  public set: string = 'BKP';
  public setNumber: string = '104';
  public fullName: string = "Misty's Determination BKP";
}

export class TiernoBKP extends Tierno {
  public set: string = 'BKP';
  public setNumber: string = '112';
  public fullName: string = 'Tierno BKP';
}

export class GyaradosEx2 extends GyaradosEx {
  public set: string = 'BKP';
  public setNumber: string = '114';
  public fullName: string = 'Gyarados-EX BKP 114';
}

export class MGyaradosEx2 extends MGyaradosEx {
  public set: string = 'BKP';
  public setNumber: string = '115';
  public fullName: string = 'M Gyarados-EX BKP 115';
}

export class EspeonEx2 extends EspeonEX {
  public set: string = 'BKP';
  public setNumber: string = '117';
  public fullName: string = 'Espeon-EX BKP 117';
}

export class DarkraiEx2 extends DarkraiEx {
  public set: string = 'BKP';
  public setNumber: string = '118';
  public fullName: string = 'Darkrai-EX BKP 118';
}

export class ScizorEx2 extends ScizorEx {
  public set: string = 'BKP';
  public setNumber: string = '119';
  public fullName: string = 'Scizor-EX BKP 119';
}

export class MScizorEx2 extends MScizorEx {
  public set: string = 'BKP';
  public setNumber: string = '120';
  public fullName: string = 'M Scizor-EX BKP 120';
}

export class GyaradosEx3 extends GyaradosEx {
  public set: string = 'BKP';
  public setNumber: string = '123';
  public fullName: string = 'Gyarados-EX BKP 123';
}
