import {smToolCapacity} from '../../../tcg-lab-sm-environment';
import { withWotcMindGames } from '../prefabs/wotc-trainer-cancellation';
import {
  AttachPokemonToolEffect, TrainerEffect, PlaySupporterEffect,
  PlayItemEffect, PlayStadiumEffect
} from '../effects/play-card-effects';
import { GameError } from '../../game-error';
import { GameMessage, GameLog } from '../../game-message';
import { Effect } from '../effects/effect';
import { State } from '../state/state';
import { StoreLike } from '../store-like';
import { StateUtils } from '../state-utils';
import { CardTag, TrainerType } from '../card/card-types';
import { Player } from '../state/player';
import { TrainerCard } from '../card/trainer-card';
import { CoinFlipEffect } from '../effects/play-card-effects';

function getTrainerCleanupTarget(player: Player, trainerCard: TrainerCard) {
  return trainerCard.tags.includes(CardTag.PRISM_STAR) ? player.lostzone : player.discard;
}

function restorePlayedTrainerToPlayZoneIfNeeded(store: StoreLike, player: Player, trainerCard: TrainerCard) {
  // Legacy card implementations may discard immediately even though prompts are pending.
  // If prompts exist, keep the played trainer visible in the play zone until completion.
  if (!store.hasPrompts()) {
    return;
  }

  if (player.discard.cards.includes(trainerCard)) {
    player.discard.moveCardTo(trainerCard, player.supporter);
  }
}

function finalizeTrainerCleanup(
  store: StoreLike,
  state: State,
  player: Player,
  trainerCard: TrainerCard,
  keepSupporterUntilEndTurn: boolean
): State {
  if((state.rules as any).dpEraRules&&trainerCard.trainerType===TrainerType.SUPPORTER){const notify=()=>{store.reduceEffect(state,{type:'DP_SUPPORTER_RESOLVED',player,trainerCard,preventDefault:false} as any);};if(store.hasPrompts())store.waitPrompt(state,notify);else notify();}
  if (keepSupporterUntilEndTurn || (trainerCard as any)._dpReturnSupporter) {
    return state;
  }

  const cleanup = () => {
    if (!player.supporter.cards.includes(trainerCard)) {
      return;
    }
    const target = getTrainerCleanupTarget(player, trainerCard);
    player.supporter.moveCardTo(trainerCard, target);
  };

  if (store.hasPrompts()) {
    return store.waitPrompt(state, cleanup);
  }

  cleanup();
  return state;
}

function withOptionalCoinFlipCancelTrainer(store:StoreLike,state:State,player:Player,trainerCard:TrainerCard,onContinue:()=>State):State {
 if((player as any).wotcTrainerLockUntilTurn>=state.turn)throw new GameError(GameMessage.BLOCKED_BY_EFFECT);
 return withWotcMindGames(store,state,player,trainerCard,()=>withCoinFlipCancelTrainerOnly(store,state,player,trainerCard,onContinue));
}

/**
 * Dizzying Wind-style: when playing a Trainer, flip a coin; on tails discard
 * with no effect. On heads (or when the flag is inactive), run `onContinue`.
 */
function withCoinFlipCancelTrainerOnly(
  store: StoreLike,
  state: State,
  player: Player,
  trainerCard: TrainerCard,
  onContinue: () => State,
): State {
  if (player.coinFlipCancelTrainerPlayTurnsRemaining <= 0) {
    return onContinue();
  }

  const coinFlip = new CoinFlipEffect(player, result => {
    if (!result) {
      const target = getTrainerCleanupTarget(player, trainerCard);
      if (player.hand.cards.includes(trainerCard)) {
        player.hand.moveCardTo(trainerCard, target);
      } else if (player.supporter.cards.includes(trainerCard)) {
        player.supporter.moveCardTo(trainerCard, target);
      }
      return;
    }
    onContinue();
  });
  return store.reduceEffect(state, coinFlip);
}


export function playTrainerReducer(store: StoreLike, state: State, effect: Effect): State {

  /* Play supporter card */
  if (effect instanceof PlaySupporterEffect) {
    const player = effect.player;

    if (player.cannotPlaySupporterCards) {
      throw new GameError(GameMessage.BLOCKED_BY_EFFECT);
    }

    return withOptionalCoinFlipCancelTrainer(store, state, player, effect.trainerCard, () => {
      const playTrainer = new TrainerEffect(player, effect.trainerCard, effect.target);
      state = store.reduceEffect(state, playTrainer);
      restorePlayedTrainerToPlayZoneIfNeeded(store, player, effect.trainerCard);
      state = finalizeTrainerCleanup(
        store,
        state,
        player,
        effect.trainerCard,
        state.rules.supporterCleanupAtEndTurn
      );
      store.log(state, GameLog.LOG_PLAYER_PLAYS_SUPPORTER, {
        name: player.name,
        card: effect.trainerCard.name
      });

      player.supporterTurn += 1;

      return state;
    });
  }

  /* Play stadium card */
  if (effect instanceof PlayStadiumEffect) {
    const player = effect.player;
    const opponent = StateUtils.getOpponent(state, player);
    const stadiumCard = StateUtils.getStadiumCard(state);

    if (player.cannotPlayStadiumCards) {
      throw new GameError(GameMessage.BLOCKED_BY_EFFECT);
    }

    const applyStadium=() => {
      // Handle player's existing stadium
      if (player.stadium.cards.length > 0) {
        if (stadiumCard && stadiumCard.tags.includes(CardTag.PRISM_STAR)) {
          player.stadium.moveTo(player.lostzone);
        } else {
          player.stadium.moveTo(player.discard);
        }
      }

      // Handle opponent's existing stadium
      if (opponent.stadium.cards.length > 0) {
        if (stadiumCard && stadiumCard.tags.includes(CardTag.PRISM_STAR)) {
          opponent.stadium.moveTo(opponent.lostzone);
        } else {
          opponent.stadium.moveTo(opponent.discard);
        }
      }

      store.log(state, GameLog.LOG_PLAYER_PLAYS_STADIUM, {
        name: effect.player.name,
        card: effect.trainerCard.name
      });
      player.stadiumUsedTurn = 0;
      ((effect as any)._exFromDeck?player.deck:player.hand).moveCardTo(effect.trainerCard, player.stadium);
      return state;
    };
    return (effect as any)._exFromDeck?applyStadium():withOptionalCoinFlipCancelTrainer(store,state,player,effect.trainerCard,applyStadium);
  }

  // Play Pokemon Tool card
  if (effect instanceof AttachPokemonToolEffect) {
    const player = effect.player;
    const target = effect.target;
    const trainerCard = effect.trainerCard;
    const pokemonCard = target.getPokemonCard();
    const targetOwner = StateUtils.findOwner(state, target);

    if (targetOwner !== player && !trainerCard.attachesToOpponentsPokemon) {
      throw new GameError(GameMessage.INVALID_TARGET);
    }

    if (pokemonCard === undefined) {
      throw new GameError(GameMessage.INVALID_TARGET);
    }
    if (effect.target.tools.length >= smToolCapacity(store,state,targetOwner,target)) {
      throw new GameError(GameMessage.POKEMON_TOOL_ALREADY_ATTACHED);
    }
    if (player.cannotPlayToolCards && !(effect as any)._exFromDeck) {
      throw new GameError(GameMessage.BLOCKED_BY_EFFECT);
    }

    const attachTool = () => {
      store.log(state, GameLog.LOG_PLAYER_PLAYS_TOOL, {
        name: player.name,
        card: trainerCard.name,
        pokemon: pokemonCard.name
      });
      player.hand.moveCardTo(trainerCard, target);
      // Remove from cards if present (should only be in tools)
      const idx = target.cards.indexOf(trainerCard);
      if (idx !== -1) {
        target.cards.splice(idx, 1);
      }
      target.tools.push(effect.trainerCard);

      if (!(effect as any)._exFromDeck) { const playTrainer = new TrainerEffect(player, trainerCard, target);
      state = store.reduceEffect(state, playTrainer); }

      return state;
    };
    return (effect as any)._exFromDeck ? attachTool() : withOptionalCoinFlipCancelTrainer(store,state,player,trainerCard,attachTool);
  }

  // Play item card
  if (effect instanceof PlayItemEffect) {
    const player = effect.player;
    if (player.cannotPlayItemCards) {
      throw new GameError(GameMessage.BLOCKED_BY_EFFECT);
    }

    return withOptionalCoinFlipCancelTrainer(store, state, player, effect.trainerCard, () => {
      const playTrainer = new TrainerEffect(effect.player, effect.trainerCard, effect.target);
      effect.player.hand.moveCardTo(effect.trainerCard, effect.player.supporter);
      state = store.reduceEffect(state, playTrainer);
      restorePlayedTrainerToPlayZoneIfNeeded(store, effect.player, effect.trainerCard);
      state = finalizeTrainerCleanup(store, state, effect.player, effect.trainerCard, false);
      store.log(state, GameLog.LOG_PLAYER_PLAYS_ITEM, {
        name: effect.player.name,
        card: effect.trainerCard.name
      });

      return state;
    });
  }

  // Process trainer effect
  if (effect instanceof TrainerEffect) {
    if (effect.player.hand.cards.includes(effect.trainerCard)) {
      // IF DIAMOND/PEARL FORMAT, SUPPORTER WILL STAY ON FIELD UNTIL THE END OF YOUR TURN
      const isSupporter = effect.trainerCard.trainerType === TrainerType.SUPPORTER;
      const target = isSupporter ? effect.player.supporter : effect.player.discard;
      effect.player.hand.moveCardTo(effect.trainerCard, target);
    }
    return state;
  }
  return state;
}
