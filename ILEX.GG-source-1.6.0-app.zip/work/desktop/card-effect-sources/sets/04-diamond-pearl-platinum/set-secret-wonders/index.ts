import { BebesSearchSW, PlusPowerSW, PotionSW, SwitchSW, DarknessEnergySpecialSW, MetalEnergyN1SW } from './other-prints';
import { Card } from '../../../game/store/card/card';
import { Bulbasaur } from './bulbasaur';
import { Charmeleon } from './charmeleon';
import { Duskull } from './duskull';
import { Electabuzz } from './electabuzz';
import { Electivire } from './electivire';
import { Flaaffy } from './flaaffy';
import { Gallade } from './gallade';
import { Gardevoir } from './gardevoir';
import { GardevoirLVX } from './gardevoir-lv-x';
import { Hoppip } from './hoppip';
import { Kirlia } from './kirlia';
import { Mew } from './mew';
import { Minun } from './minun';
import { Murkrow } from './murkrow';
import { Pidgeotto } from './pidgeotto';
import { Pidgey } from './pidgey';
import { Plusle } from './plusle';
import { Ralts } from './ralts';
import { RoseannesResearch } from './roseannes-research';
import { Sentret } from './sentret';
import { Skiploom } from './skiploom';
import { Trapinch } from './trapinch';

// Other Prints
import { NightMaintenanceSW } from './other-prints';

export const setSecretWonders: Card[] = [
  new Bulbasaur(),
  new Charmeleon(),
  new Duskull(),
  new Electabuzz(),
  new Electivire(),
  new Flaaffy(),
  new Gallade(),
  new Mew(),
  new Minun(),
  new Murkrow(),
  new Pidgeotto(),
  new Pidgey(),
  new Plusle(),
  new Ralts(),
  new Kirlia(),
  new Gardevoir(),
  new GardevoirLVX(),
  new Hoppip(),
  new RoseannesResearch(),
  new Sentret(),
  new Skiploom(),
  new Trapinch(),

  // Other Prints
  new NightMaintenanceSW(),
  new BebesSearchSW(),
  new PlusPowerSW(),
  new PotionSW(),
  new SwitchSW(),
  new DarknessEnergySpecialSW(),
  new MetalEnergyN1SW(),
];