import { EnergySwitchPKSF, GreatBallSF, PotionSF, SwitchSF, CharmanderSF, CharmeleonSF, CharizardSF } from './other-prints';
import { Card } from '../../../game/store/card/card';
import { Combee } from './combee';
import { Dusclops } from './dusclops';
import { Dusclops2 } from './dusclops2';
import { Duskull } from './duskull';
import { Gastly } from './gastly';
import { Gengar } from './gengar';
import { Gyarados } from './gyarados';
import { Haunter } from './haunter';
import { LuxuryBall } from './luxury-ball';
import { Machoke } from './machoke';
import { Machamp } from './machamp';
import { MachampLVX } from './machamp-lv-x';
import { Machop } from './machop';
import { Magikarp } from './magikarp';
import { MarleysRequest } from './marleys-request';
import { PokeBlower } from './poke-blower';
import { PokeDrawer } from './poke-drawer';
import { RegigigasLVX } from './regigigas-lv-x';
import { Sableye } from './sableye';

// Other prints
import {
  CycloneEnergySF,
  PremierBallSF,
  WarpEnergySF
} from './other-prints';

export const setStormfront: Card[] = [
  new Combee(),
  new Dusclops(),
  new Dusclops2(),
  new Duskull(),
  new Gengar(),
  new Gyarados(),
  new Haunter(),
  new LuxuryBall(),
  new Machoke(),
  new Machamp(),
  new MachampLVX(),
  new Machop(),
  new Magikarp(),
  new MarleysRequest(),
  new PokeBlower(),
  new PokeDrawer(),
  new RegigigasLVX(),
  new Sableye(),
  new Gastly(),
  // Other prints
  new CycloneEnergySF(),
  new PremierBallSF(),
  new WarpEnergySF(),
  new EnergySwitchPKSF(),
  new GreatBallSF(),
  new PotionSF(),
  new SwitchSF(),
  new CharmanderSF(),
  new CharmeleonSF(),
  new CharizardSF(),
];
