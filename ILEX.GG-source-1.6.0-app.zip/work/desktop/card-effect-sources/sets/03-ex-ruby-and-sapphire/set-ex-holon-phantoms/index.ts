import { Card } from '../../../game/store/card/card';
import { GrassEnergy, FireEnergy, WaterEnergy, LightningEnergy, PsychicEnergy, FightingEnergy } from './basic-energies';
import { Aerodactyl } from './aerodactyl';
import { Armaldo } from './armaldo';
import { Chimecho } from './chimecho';
import { Corphish } from './corphish';
import { CrawdauntEx } from './crawdaunt-ex';
import { DeltaRainbowEnergy } from './delta-rainbow-energy';
import { Deoxys } from './deoxys';
import { Exeggcute } from './exeggcute';
import { Exeggutor } from './exeggutor';
import { Flygon } from './flygon';
import { HolonAdventurer } from './holon-adventurer';
import { HolonFossil } from './holon-fossil';
import { HolonsCastform } from './holons-castform';
import { Horsea } from './horsea';
import { Latias } from './latias';
import { Meowth } from './meowth';
import { Oddish } from './oddish';
import { Omastar } from './omastar';
import { Pidgeot } from './pidgeot';
import { Pidgey } from './pidgey';
import { Pidgeotto } from './pidgeotto';
import { Pikachu } from './pikachu';
import { Raichu } from './raichu';
import { RareCandy } from './rare-candy';
import { Trapinch } from './trapinch';
import { Vibrava } from './vibrava';

// Other Prints
import {
  DarknessEnergySpecialHP
} from './other-prints';

export const setEXHolonPhantoms: Card[] = [
  new Aerodactyl(),
  new Armaldo(),
  new Chimecho(),
  new Corphish(),
  new CrawdauntEx(),
  new DeltaRainbowEnergy(),
  new Deoxys(),
  new Exeggcute(),
  new Exeggutor(),
  new Flygon(),
  new Horsea(),
  new Latias(),
  new Meowth(),
  new Oddish(),
  new Omastar(),
  new Pidgeot(),
  new Pidgey(),
  new Pidgeotto(),
  new Pikachu(),
  new Raichu(),
  new RareCandy(),
  new HolonAdventurer(),
  new HolonFossil(),
  new HolonsCastform(),
  new Trapinch(),
  new Vibrava(),


  // Other Prints
  new DarknessEnergySpecialHP(),

  // Basic energies
  new GrassEnergy(),
  new FireEnergy(),
  new WaterEnergy(),
  new LightningEnergy(),
  new PsychicEnergy(),
  new FightingEnergy(),
];
