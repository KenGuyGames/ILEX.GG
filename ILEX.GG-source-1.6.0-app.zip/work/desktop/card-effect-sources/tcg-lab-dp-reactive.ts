import { becomeDpPokemonEnergy,becomeDpPokemonStadium } from './tcg-lab-dp-card-roles';
import { StateUtils,PowerType,EnergyType,SuperType,SpecialCondition,PlayerType,SlotType,ChoosePokemonPrompt,CardList,SelectPrompt,ChooseCardsPrompt,GameMessage } from './game';
import { KnockOutEffect,PowerEffect } from './game/store/effects/game-effects';
import { AfterDamageEffect } from './game/store/effects/attack-effects';
import { CheckHpEffect,AddSpecialConditionsPowerEffect } from './game/store/effects/check-effects';
import { MOVE_POKEMON_OFF_BOARD,MOVE_CARDS,COIN_FLIP_PROMPT } from './game/store/prefabs/prefabs';
import { exAttachedEnergy } from './tcg-lab-ex-attachments';
import { attachWotcEnergy } from './game/store/prefabs/wotc-energy-attachment';
export function dpReactiveTrigger(op:any,e:any,p:any,list:any,card:any,state:any){
 if(op.kind==='dpKoReaction')return (op.bothTurns||op.ownTurn?op.bothTurns||state.players[state.activePlayer]===p:state.players[state.activePlayer]!==p)&&e instanceof KnockOutEffect&&e.target===list&&(!op.active||p.active===list||op.effect==='stadium'&&list._exLethalAttackDamage?.wasActive)&&!e._dpReactiveDone?.includes(card.id+':'+op.kind)&&list._exLethalAttackDamage?.turn===state.turn&&list._exLethalAttackDamage.card===card;
 if(op.kind==='dpAttackKoMill')return e instanceof KnockOutEffect&&e.player!==p&&e.target._exLethalAttackDamage?.turn===state.turn&&e.target._exLethalAttackDamage.attackerCard===card;
 if(op.kind!=='dpDamagedReaction')return false;
 return e instanceof AfterDamageEffect&&e.player!==p&&e.damage>0&&!e.attackEffect._wotcTrainer&&(op.teamActive?e.target===p.active:e.target===list)&&(!op.active||p.active===list);
}
export function dpReactivePower(card:any,op:any,power:any,index:number,store:any,state:any,e:any,p:any,list:any,use:()=>void){
 const o=StateUtils.getOpponent(state,p),provenance=new PowerEffect(p,power,card),move=(from:any,to:any,cards:any[])=>MOVE_CARDS(store,state,from,to,{cards,sourceCard:card,sourceEffect:provenance});
 const counters=(target:any,amount:number)=>{if(!target?.getPokemonCard()||!amount)return;const hit:any={type:'EX_POWER_COUNTERS_EFFECT',player:p,source:list,target,sourceCard:card,powerType:power.powerType,damage:amount,preventDefault:false};store.reduceEffect(state,hit);if(!hit.preventDefault)target.damage+=hit.damage;};
 if(op.kind==='dpAttackKoMill'){if(e._dpKoMill?.includes(card.id))return state;e._dpKoMill??=[];e._dpKoMill.push(card.id);move(o.deck,o.discard,o.deck.cards.slice(0,op.amount));return state;}
 if(op.kind==='dpKoReaction'){
  if(op.once&&card._wotcPowerTurn?.[index]===state.turn)return state;
  const lethal=list._exLethalAttackDamage,attacker=lethal?.attackerCard&&StateUtils.findPokemonSlot(state,lethal.attackerCard);if(!attacker&&!['retain','stadium','energy'].includes(op.effect))return state;
  e._dpReactiveDone??=[];e._dpReactiveDone.push(card.id+':'+op.kind);e.preventDefault=true;
  const resume=()=>{const apply=()=>{for(const tool of e._dpBeltPrizeTools||[])if(!list.tools.includes(tool)){e.prizeCount--;e._dpBeltPrizeTools=e._dpBeltPrizeTools.filter((item:any)=>item!==tool);}e.preventDefault=false;e._dpResumeCore=true;store.reduceEffect(state,e);};if(store.hasPrompts())store.waitPrompt(state,apply);else apply();};
  return store.prompt(state,new SelectPrompt(p.id,GameMessage.CHOOSE_OPTION,['Skip Power','Use Power'],{allowCancel:false}),(choice:number)=>{if(choice!==1)return resume();use();if(op.effect==='energy'){const slots=[{player:PlayerType.BOTTOM_PLAYER,slot:SlotType.ACTIVE,index:0,list:p.active},...p.bench.map((list:any,index:number)=>({player:PlayerType.BOTTOM_PLAYER,slot:SlotType.BENCH,index,list}))],eligible=slots.filter((slot:any)=>slot.list!==list&&slot.list.getPokemonCard());if(!eligible.length)return resume();return store.prompt(state,new ChoosePokemonPrompt(p.id,GameMessage.CHOOSE_POKEMON_TO_ATTACH_CARDS,PlayerType.BOTTOM_PLAYER,[SlotType.ACTIVE,SlotType.BENCH],{allowCancel:false,blocked:slots.filter((slot:any)=>!eligible.includes(slot)).map(({list,...target}:any)=>target)}),(chosen:any)=>{const held=new CardList();e._dpReplacementKoCard=card;e._dpRetainPokemon=true;MOVE_POKEMON_OFF_BOARD(store,state,list,{pokemonDestination:held,attachedDestination:p.discard,sourceCard:card,sourceEffect:provenance});move(held,p.discard,held.cards.filter((entry:any)=>entry!==card));becomeDpPokemonEnergy(card);attachWotcEnergy(store,state,p,held,chosen[0],card,{sourceCard:card,sourceEffect:provenance,sourceKind:'power'});resume();});}if(op.effect==='stadium'){const held=new CardList();e._dpReplacementKoCard=card;e._dpRetainPokemon=true;MOVE_POKEMON_OFF_BOARD(store,state,list,{pokemonDestination:held,attachedDestination:p.discard,sourceCard:card,sourceEffect:provenance});move(held,p.discard,held.cards.filter((entry:any)=>entry!==card));for(const owner of state.players)move(owner.stadium,owner.discard,owner.stadium.cards.slice());becomeDpPokemonStadium(card,p);move(held,p.stadium,[card]);return resume();}if(op.effect==='namedCounters'){const name=attacker?.getPokemonCard()?.name;for(const target of [o.active,...o.bench])if(name&&target.getPokemonCard()?.name===name)counters(target,op.amount);return resume();}COIN_FLIP_PROMPT(store,state,p,heads=>{if(heads&&op.effect==='retain'){const energy=new Set(exAttachedEnergy(store,state,p,list).map((entry:any)=>entry.card));const attached=[...new Set([...list.cards,...list.energies.cards,...list.tools])].filter((entry:any)=>entry!==card&&!energy.has(entry));for(const item of attached)move(list.energies.cards.includes(item)?list.energies:list,p.discard,[item]);list.damage=0;list.clearEffects();list._exLethalAttackDamage=undefined;e._dpRetainPokemon=true;}else if(heads&&attacker?.getPokemonCard()){attacker._exLethalAttackDamage=undefined;attacker.exForcedKo={card:attacker.getPokemonCard(),sourceCard:card,power:true};attacker.marker.addMarker('EX_FORCED_KO',card,'power','pokemon');}resume();});});
 }
 if(op.once&&card._wotcPowerTurn?.[index]===state.turn)return state;
 if(op.once&&state.players[state.activePlayer]===p)return state;
 const attacker=e.source;
 if(op.notKo){const hp=new CheckHpEffect(p,list);store.reduceEffect(state,hp);if(list.damage>=hp.hp)return state;}
 if(op.effect==='attach'&&!p.discard.cards.some((card:any)=>card.superType===SuperType.ENERGY))return state;
 const perform=()=>{
  if(power.powerType===PowerType.POKEPOWER)use();
  if(op.effect==='status')store.reduceEffect(state,new AddSpecialConditionsPowerEffect(p,card,attacker,op.statuses.map((status:string)=>(SpecialCondition as any)[status]),op.poison||10));
  if(op.effect==='counters'){
   if(op.nonstack){e.attackEffect._dpCounterReactions??={};if(e.attackEffect._dpCounterReactions[p.id+':'+power.name])return;e.attackEffect._dpCounterReactions[p.id+':'+power.name]=true;}
   for(const target of op.field?[o.active,...o.bench]:[attacker])counters(target,op.amount);
  }
  if(op.effect==='memory'){attacker._dpTimedAttackLocks??=[];attacker._dpTimedAttackLocks.push({name:e.attack._wotcOriginalAttack?.name||e.attack.name,turn:state.turn+2,card});attacker.marker.addMarker('DP_TIMED_ATTACK_LOCK',card,'power','pokemon');}
  if(op.effect==='energy'){
   const entries=exAttachedEnergy(store,state,o,attacker);if(!entries.length)return;const view=new CardList();view.cards=entries.map((entry:any)=>entry.card);store.prompt(state,new ChooseCardsPrompt(p,GameMessage.CHOOSE_ENERGIES_TO_DISCARD,view,{},{min:1,max:1,allowCancel:false}),(cards:any)=>{const entry=entries.find((entry:any)=>entry.card===cards[0]);move(entry.zone,op.hand?o.hand:o.discard,cards);});
  }
  if(op.effect==='attach'){const eligible=p.discard.cards.filter((card:any)=>card.superType===SuperType.ENERGY);store.prompt(state,new ChooseCardsPrompt(p,GameMessage.CHOOSE_CARD_TO_ATTACH,p.discard,{superType:SuperType.ENERGY},{min:1,max:1,allowCancel:false}),(cards:any)=>attachWotcEnergy(store,state,p,p.discard,list,cards[0],{sourceCard:card,sourceEffect:provenance,sourceKind:'power'}));}
 };
 const flip=()=>op.coin?COIN_FLIP_PROMPT(store,state,p,heads=>{if(heads)perform();else if(power.powerType===PowerType.POKEPOWER)use();}):perform();
 if(op.optional)return store.prompt(state,new SelectPrompt(p.id,GameMessage.CHOOSE_OPTION,['Skip Power','Use Power'],{allowCancel:false}),(choice:number)=>{if(choice===1)flip();});return flip();
}
