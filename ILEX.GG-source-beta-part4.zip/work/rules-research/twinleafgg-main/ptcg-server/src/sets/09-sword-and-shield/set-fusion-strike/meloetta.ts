import { PokemonCard } from '../../../game/store/card/pokemon-card';
import { Stage, CardType, CardTag, EnergyType } from '../../../game/store/card/card-types';
import { StoreLike, State, PlayerType } from '../../../game';

import { Effect } from '../../../game/store/effects/effect';
import { CheckProvidedEnergyEffect } from '../../../game/store/effects/check-effects';
import { WAS_ATTACK_USED } from '../../../game/store/prefabs/prefabs';

export class Meloetta extends PokemonCard {
  public stage: Stage = Stage.BASIC;

  public regulationMark = 'E';

  protected _tags = [CardTag.FUSION_STRIKE];

  public cardType: CardType[] = [CardType.PSYCHIC];

  public hp: number = 90;

  public weakness = [{ type: CardType.DARK }];

  public resistance = [{ type: CardType.FIGHTING, value: -30 }];

  public retreat = [CardType.COLORLESS];

  public attacks = [
    {
      name: 'Melodious Echo',
      cost: [CardType.PSYCHIC, CardType.COLORLESS],
      damage: 70,
      text:
        'This attack does 70 damage for each Fusion Strike Energy ' +
        'attached to all of your Pokémon.',
    },
  ];

  public set: string = 'FST';

  public cardImage: string = 'assets/cardback.png';

  public setNumber: string = '124';

  public name: string = 'Meloetta';

  public fullName: string = 'Meloetta FST';

  public reduceEffect(store: StoreLike, state: State, effect: Effect): State {
    if (WAS_ATTACK_USED(effect, 0, this)) {
      const player = effect.player;

      const checkProvidedEnergyEffect = new CheckProvidedEnergyEffect(player);
      store.reduceEffect(state, checkProvidedEnergyEffect);

      let energyCount = 0;
      player.forEachPokemon(PlayerType.BOTTOM_PLAYER, (cardList) => {
        if (cardList.energies.cards.some((c) => c.energyType === EnergyType.SPECIAL)) {
          checkProvidedEnergyEffect.energyMap.forEach((em) => {
            energyCount += em.provides.filter((cardType) => {
              return em.card.hasTag(CardTag.FUSION_STRIKE);
            }).length;
          });
        }
      });

      effect.damage = energyCount * 70;
      return state;
    }
    return state;
  }
}
