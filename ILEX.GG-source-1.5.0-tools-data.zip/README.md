# ILEX.GG

Desktop Pokémon TCG simulator with deck building, custom cards, historical formats, a local play table, and rules automation.

## Screenshots

Screenshots from ILEX.GG 1.5.0.

### Main menu and card library

![ILEX.GG main menu and card library](ILEX.GG-desktop-preview.png)

### Play table

![ILEX.GG play table with opposing seats, prize cards and a fanned hand](ILEX.GG-widescreen-preview.png)

### Visual deck builder

![ILEX.GG visual deck builder with card images and quantities](ILEX.GG-visual-deck-preview.png)

## Status

**The complete WOTC and EX eras are playable in ILEX.GG 1.5.0**, verified October 14, 2026.

- **WOTC:** Base Set through Skyridge, including Wizards Black Star Promos, Southern Islands, Legendary Collection, and Best of Game — **1,793/1,793 entries, zero pending**.
- **EX:** Ruby & Sapphire through Power Keepers, including the Unseen Forces Unown collection, EX Trainer Kits, Nintendo promos, and POP Series 1–3 — **1,857/1,857 entries, zero pending**.

The EX release passed 155 focused checks, 5,302 scoped attack scenarios, shared WOTC/bot/Undo regressions, and fresh/restored native desktop verification. EX interaction validation covers the EX pool plus Expedition, Aquapolis, and Skyridge. Full implementation coverage does not certify every possible interaction or ruling; Unlimited and other-era interaction sweeps remain deferred.

The current build also includes format-first match setup, Limitless collection integration, updated four-track music, Undo, attack and ability search, visual decklists, and foil effects.

## Download and play

Get the [current Windows x64 release](https://github.com/KenGuyGames/ILEX.GG/releases/tag/v1.5.0-build-2026-10-14), including the runtime and offline card scans. Download `ILEX.GG-Windows.zip.001`, `ILEX.GG-Windows.zip.002`, and `Restore-ILEX-ZIP.cmd` from that release into the same folder. Run the script to restore and checksum-verify the ZIP, extract the entire ZIP, then launch `ILEX.GG.exe`. No Node.js or Python installation is required. Do not mix files from different releases.

The source on `main` now matches the verified 1.5.0 release, including the complete WOTC and EX implementations. The app files are taken from the release ZIP, and rebuilding the rules engine reproduces its SHA-256 exactly. See `verification/source-manifest-1.5.0.json` and `verification/desktop-verification-1.5.0.json` for the recorded hashes and release checks. GitHub’s **Code → Download ZIP** provides the current source.

## Development

Use Node.js and npm. From the repository root:

```powershell
npm install
npm start
```

The app expects offline scans in `outputs/Pokemon-TCG-Lab/scans`. Copy that directory from the existing local ILEX.GG project before launching for full offline artwork. Scans, Electron runtimes, packaged executables, personal profiles, and generated test output are excluded from Git.

The original source layout is preserved so existing scripts keep their relative paths. Build-tool dependencies:

```powershell
npm ci --prefix work/desktop-build
node work/desktop-build/wotc-library.cjs
node work/desktop-build/build-rules.cjs
node work/desktop-build/catalog.cjs
```

`npm run build:rules` bundles the checked-in TypeScript into the release engine. The card compiler and catalog-generation tools are also included for further development. Do not regenerate catalogs merely to launch the checked-in app.

Run dependent commands sequentially. Rules checks:

```powershell
node work/desktop-build/wotc-tests.cjs
node work/desktop-build/bot-tests.cjs
```

Legacy packaging/install scripts also expect the original local output folders and test profiles; they are retained as project history and are not a clean-clone release pipeline. Do not run `build.cjs` to update the current UI: it reconstructs an older base app.

## Credits and rights

Unofficial fan project. Pokémon names, card text and artwork belong to their respective owners. The rules engine includes modified Twinleaf code; its MIT notice is preserved in `work/desktop/ui/rules-engine-LICENSE.txt`. Card metadata originated from pokemon-tcg-data. No new license is granted for the original ILEX.GG code or third-party assets by this upload.

