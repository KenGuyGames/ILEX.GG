import { Format, Archetype } from '../card/card-types';

// =============================================================================
// Theme deck definitions
// =============================================================================

export const THEME_DECKS = [
  {
    id: -1,
    name: 'Soaring Skies',
    cards: ['Alolan Grimer UNM', 'Alolan Grimer UNM', 'Chinchou CES', 'Chinchou CES', 'Lanturn CES', 'Lanturn CES', 'Dratini UNM', 'Dratini UNM', 'Dratini UNM', 'Dragonair UNM', 'Dragonair UNM', 'Dragonair UNM', 'Dragonite UNM', 'Dragonite UNM', 'Pidgey TEU', 'Pidgey TEU', 'Pidgey TEU', 'Pidgeotto TEU', 'Pidgeotto TEU', 'Pidgeot TEU', 'Thundurus UNM', 'Thundurus UNM', 'Tornadus UNM', 'Tornadus UNM', 'Bug Catcher UNM', 'Bug Catcher UNM', 'Cynthia UPR', 'Cynthia UPR', 'Fisherman CES', 'Hau CES', 'Hau CES', 'Lillie UPR', 'Lillie UPR', 'Pokémon Fan Club UPR', 'Pokémon Fan Club UPR', 'Tate & Liza CES', 'Energy Recycle System CES', 'Pokemon Communication TEU', 'Pokemon Communication TEU', 'Switch CES', 'Lightning Energy SUM', 'Lightning Energy SUM', 'Lightning Energy SUM', 'Lightning Energy SUM', 'Lightning Energy SUM', 'Lightning Energy SUM', 'Lightning Energy SUM', 'Lightning Energy SUM', 'Lightning Energy SUM', 'Lightning Energy SUM', 'Lightning Energy SUM', 'Water Energy SUM', 'Water Energy SUM', 'Water Energy SUM', 'Water Energy SUM', 'Water Energy SUM', 'Water Energy SUM', 'Water Energy SUM', 'Water Energy SUM', 'Water Energy SUM'],
    format: [Format.THEME],
    isValid: true,
    cardTypes: '[]',
    manualArchetype1: Archetype.DRAGONITE,
    manualArchetype2: Archetype.PIDGEOTTO,
  },
  {
    id: -2,
    name: 'Relentless Flame',
    cards: ['Charmander TEU2', 'Charmander TEU2', 'Charmander TEU2', 'Charmeleon TEU', 'Charmeleon TEU', 'Farfetch\'d TEU', 'Farfetch\'d TEU', 'Farfetch\'d TEU', 'Charizard TEU', 'Charizard TEU', 'Nidoran F TEU', 'Nidoran F TEU', 'Nidoran F TEU', 'Nidorina TEU', 'Nidorina TEU', 'Ponyta TEU', 'Ponyta TEU', 'Ponyta TEU', 'Nidoqueen TEU', 'Nidoqueen TEU', 'Rapidash TEU', 'Rapidash TEU', 'Brock\'s Grit TEU', 'Brock\'s Grit TEU', 'Copycat CES', 'Copycat CES', 'Cynthia UPR', 'Cynthia UPR', 'Hau CES', 'Hau CES', 'Pokémon Fan Club UPR', 'Pokémon Fan Club UPR', 'Professor Kukui SUM', 'Professor Kukui SUM', 'Nest Ball SUM', 'Nest Ball SUM', 'Switch CES', 'Switch CES', 'Timer Ball SUM', 'Timer Ball SUM', 'Fire Energy SUM', 'Fire Energy SUM', 'Fire Energy SUM', 'Fire Energy SUM', 'Fire Energy SUM', 'Fire Energy SUM', 'Fire Energy SUM', 'Fire Energy SUM', 'Fire Energy SUM', 'Fire Energy SUM', 'Fire Energy SUM', 'Fire Energy SUM', 'Fire Energy SUM', 'Fire Energy SUM', 'Fire Energy SUM', 'Fire Energy SUM', 'Fire Energy SUM', 'Fire Energy SUM', 'Fire Energy SUM', 'Fire Energy SUM'],
    format: [Format.THEME],
    isValid: true,
    cardTypes: '[]',
    manualArchetype1: Archetype.CHARIZARD,
    manualArchetype2: Archetype.NIDOQUEEN,
  },
  {
    id: -3,
    name: 'Charizard',
    cards: ['Charmander VIV', 'Charmander VIV', 'Charmander VIV', 'Charmeleon VIV', 'Charmeleon VIV', 'Charmeleon VIV', 'Lugia DAA', 'Charizard SWSH', 'Charizard VIV', 'Slugma VIV', 'Slugma VIV', 'Slugma VIV', 'Sudowoodo SSH', 'Sudowoodo SSH', 'Magcargo VIV', 'Magcargo VIV', 'Yanma VIV', 'Yanma VIV', 'Yanma VIV', 'Yanmega VIV', 'Yanmega VIV', 'Bede SSH', 'Bede SSH', 'Dan RCL', 'Dan RCL', 'Hop SSH', 'Hop SSH', 'Hop SSH', 'Hop SSH', 'Leon VIV', 'Leon VIV', 'Professors Research SSH', 'Professors Research SSH', 'Sonia CPA', 'Sonia CPA', 'Evolution Incense SSH', 'Great Ball SSH', 'Great Ball SSH', 'Ordinary Rod SSH', 'Ordinary Rod SSH', 'Switch SSH', 'Switch SSH', 'Fire Energy SSH', 'Fire Energy SSH', 'Fire Energy SSH', 'Fire Energy SSH', 'Fire Energy SSH', 'Fire Energy SSH', 'Fire Energy SSH', 'Fire Energy SSH', 'Fire Energy SSH', 'Fire Energy SSH', 'Fire Energy SSH', 'Fire Energy SSH', 'Fire Energy SSH', 'Fire Energy SSH', 'Fire Energy SSH', 'Fire Energy SSH', 'Fire Energy SSH', 'Fire Energy SSH'],
    format: [Format.THEME],
    isValid: true,
    cardTypes: '[]',
    manualArchetype1: Archetype.CHARIZARD,
  },
  {
    id: -4,
    name: 'Twilight Rogue',
    cards: ['Dusknoir BUS', 'Dusknoir BUS', 'Duskull BUS', 'Duskull BUS', 'Duskull BUS', 'Furfrou FLI', 'Dusclops BUS', 'Dusclops BUS', 'Inkay FLI', 'Inkay FLI', 'Malamar FLI', 'Lycanroc SMP', 'Rockruff FLI', 'Rockruff FLI', 'Rockruff FLI', 'Salandit CIN', 'Salandit CIN', 'Lycanroc FLI', 'Salazzle CIN', 'Salazzle CIN', 'Solrock BUS', 'Cynthia UPR', 'Hau SUM', 'Hau SUM', 'Lady FLI', 'Lillie UPR', 'Pokémon Fan Club UPR', 'Professor Kukui SUM', 'Professor Kukui SUM', 'Escape Rope BUS', 'Field Blower GRI', 'Nest Ball SUM', 'Nest Ball SUM', 'Rescue Stretcher GRI', 'Switch CES', 'Timer Ball SUM', 'Timer Ball SUM', 'Escape Board UPR', 'Weakness Policy BUS', 'Brooklet Hill GRI', 'Fighting Energy SUM', 'Fighting Energy SUM', 'Fighting Energy SUM', 'Fighting Energy SUM', 'Fighting Energy SUM', 'Fighting Energy SUM', 'Fighting Energy SUM', 'Fighting Energy SUM', 'Fighting Energy SUM', 'Fighting Energy SUM', 'Psychic Energy SUM', 'Psychic Energy SUM', 'Psychic Energy SUM', 'Psychic Energy SUM', 'Psychic Energy SUM', 'Psychic Energy SUM', 'Psychic Energy SUM', 'Psychic Energy SUM', 'Psychic Energy SUM', 'Psychic Energy SUM'],
    format: [Format.THEME],
    isValid: true,
    cardTypes: '[]',
    manualArchetype1: Archetype.LYCANROC,
    manualArchetype2: Archetype.DUSKNOIR,
  },
  {
    id: -5,
    name: 'Towering Heights',
    cards: ['Gible UNM', 'Gible UNM', 'Gible UNM', 'Gabite UNM', 'Gabite UNM', 'Gabite UNM', 'Garchomp UNM', 'Garchomp UNM', 'Groudon CEC', 'Groudon CEC', 'Mew UNB', 'Passimian CEC', 'Passimian CEC', 'Throh CEC', 'Throh CEC', 'Tympole CEC', 'Tympole CEC', 'Tympole CEC', 'Palpitoad CEC', 'Palpitoad CEC', 'Palpitoad CEC', 'Seismitoad CEC', 'Seismitoad CEC', 'Bug Catcher UNM', 'Bug Catcher UNM', 'Cynthia UPR', 'Cynthia UPR', 'Hau CES', 'Hau CES', 'Lady FLI', 'Lillie UPR', 'Lillie UPR', 'Pokémon Fan Club UPR', 'Pokémon Fan Club UPR', 'Tate & Liza CES', 'Tate & Liza CES', 'Pokemon Communication TEU', 'Pokemon Communication TEU', 'Switch CES', 'Switch CES', 'Fighting Energy SUM', 'Fighting Energy SUM', 'Fighting Energy SUM', 'Fighting Energy SUM', 'Fighting Energy SUM', 'Fighting Energy SUM', 'Fighting Energy SUM', 'Fighting Energy SUM', 'Fighting Energy SUM', 'Fighting Energy SUM', 'Fighting Energy SUM', 'Fighting Energy SUM', 'Fighting Energy SUM', 'Fighting Energy SUM', 'Fighting Energy SUM', 'Fighting Energy SUM', 'Fighting Energy SUM', 'Fighting Energy SUM', 'Draw Energy CEC', 'Draw Energy CEC'],
    format: [Format.THEME],
    isValid: true,
    cardTypes: '[]',
    manualArchetype1: Archetype.GROUDON,
    manualArchetype2: Archetype.GARCHOMP,
  },
  {
    id: -6,
    name: 'Unseen Depths',
    cards: ['Aipom CEC', 'Aipom CEC', 'Aipom CEC', 'Ambipom CEC', 'Ambipom CEC', 'Kyogre CEC', 'Kyogre CEC', 'Phione CEC', 'Piplup CEC', 'Piplup CEC', 'Piplup CEC', 'Prinplup CEC', 'Prinplup CEC', 'Prinplup CEC', 'Empoleon CEC', 'Empoleon CEC', 'Psyduck CEC', 'Psyduck CEC', 'Psyduck CEC', 'Golduck CEC', 'Golduck CEC', 'Pyukumuku UNB', 'Pyukumuku UNB', 'Cynthia UPR', 'Cynthia UPR', 'Hau CES', 'Hau CES', 'Lillie UPR', 'Lillie UPR', 'Pokémon Fan Club UPR', 'Pokémon Fan Club UPR', 'Roller Skater CEC', 'Roller Skater CEC', 'Tate & Liza CES', 'Tate & Liza CES', 'Pokemon Communication TEU', 'Pokemon Communication TEU', 'Switch CES', 'Switch CES', 'Viridian Forest TEU', 'Water Energy SUM', 'Water Energy SUM', 'Water Energy SUM', 'Water Energy SUM', 'Water Energy SUM', 'Water Energy SUM', 'Water Energy SUM', 'Water Energy SUM', 'Water Energy SUM', 'Water Energy SUM', 'Water Energy SUM', 'Water Energy SUM', 'Water Energy SUM', 'Water Energy SUM', 'Water Energy SUM', 'Water Energy SUM', 'Water Energy SUM', 'Water Energy SUM', 'Draw Energy CEC', 'Draw Energy CEC'],
    format: [Format.THEME],
    isValid: true,
    cardTypes: '[]',
    manualArchetype1: Archetype.KYOGRE,
    manualArchetype2: Archetype.EMPOLEON,
  },
  {
    id: -7,
    name: 'Laser Focus',
    cards: ['Audino UNM', 'Audino UNM', 'Dedenne UNM', 'Dedenne UNM', 'Inkay FLI', 'Inkay FLI', 'Malamar FLI', 'Malamar FLI', 'Mesprit UNM', 'Mesprit UNM', 'Necrozma UNM', 'Necrozma UNM', 'Tauros UNM', 'Tauros UNM', 'Type: Null UNM', 'Type: Null UNM', 'Type: Null UNM', 'Silvally UNM', 'Silvally UNM', 'Yungoos UNM', 'Yungoos UNM', 'Yungoos UNM', 'Gumshoos UNM', 'Gumshoos UNM', 'Bug Catcher UNM', 'Bug Catcher UNM', 'Cynthia UPR', 'Cynthia UPR', 'Hau CES', 'Hau CES', 'Lillie UPR', 'Lillie UPR', 'Pokémon Fan Club UPR', 'Pokémon Fan Club UPR', 'Tate & Liza CES', 'Mysterious Treasure FLI', 'Mysterious Treasure FLI', 'Switch CES', 'U-Turn Board UNM', 'U-Turn Board UNM', 'Psychic Energy SUM', 'Psychic Energy SUM', 'Psychic Energy SUM', 'Psychic Energy SUM', 'Psychic Energy SUM', 'Psychic Energy SUM', 'Psychic Energy SUM', 'Psychic Energy SUM', 'Psychic Energy SUM', 'Psychic Energy SUM', 'Psychic Energy SUM', 'Psychic Energy SUM', 'Psychic Energy SUM', 'Psychic Energy SUM', 'Psychic Energy SUM', 'Psychic Energy SUM', 'Psychic Energy SUM', 'Psychic Energy SUM', 'Weakness Guard Energy UNM', 'Weakness Guard Energy UNM'],
    format: [Format.THEME],
    isValid: true,
    cardTypes: '[]',
    manualArchetype1: Archetype.NECROZMA,
    manualArchetype2: Archetype.MALAMAR,
  },
  {
    id: -8,
    name: 'Storm Caller',
    cards: ['Blitzle LOT', 'Blitzle LOT', 'Blitzle LOT', 'Zebstrika LOT', 'Furfrou FLI', 'Mareep LOT 76', 'Mareep LOT 76', 'Mareep LOT 76', 'Flaaffy LOT', 'Flaaffy LOT', 'Ampharos LOT', 'Ampharos LOT', 'Poipole LOT', 'Poipole LOT', 'Poipole LOT', 'Naganadel LOT', 'Naganadel LOT', 'Raikou LOT', 'Raikou LOT', 'Smeargle LOT', 'Copycat CES', 'Hau CES', 'Hau CES', 'Kahili LOT', 'Lady FLI', 'Lillie UPR', 'Pokémon Fan Club UPR', 'Professor Kukui SUM', 'Professor Kukui SUM', 'Tate & Liza CES', 'Energy Switch CES', 'Escape Rope BUS', 'Nest Ball SUM', 'Nest Ball SUM', 'Rescue Stretcher GRI', 'Rescue Stretcher GRI', 'Switch CES', 'Timer Ball SUM', 'Timer Ball SUM', 'Ultra Ball SUM', 'Lightning Energy SUM', 'Lightning Energy SUM', 'Lightning Energy SUM', 'Lightning Energy SUM', 'Lightning Energy SUM', 'Lightning Energy SUM', 'Lightning Energy SUM', 'Lightning Energy SUM', 'Lightning Energy SUM', 'Lightning Energy SUM', 'Lightning Energy SUM', 'Lightning Energy SUM', 'Lightning Energy SUM', 'Lightning Energy SUM', 'Lightning Energy SUM', 'Lightning Energy SUM', 'Lightning Energy SUM', 'Lightning Energy SUM', 'Lightning Energy SUM', 'Lightning Energy SUM'],
    format: [Format.THEME],
    isValid: true,
    cardTypes: '[]',
    manualArchetype1: Archetype.RAIKOU,
    manualArchetype2: Archetype.AMPHAROS,
  }
]; 

